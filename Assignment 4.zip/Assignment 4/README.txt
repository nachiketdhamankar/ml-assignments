
- All the source code is present in the \src\ folder with appropriate filename (according to the question number)
- All the output of the source code is in the \output\ folder with appropriate directory (according to the question number)
- All the graphs are in the \graphs\ folder with appropriate directory (according to the question number)
- All the tables are in the \tables\ folder with appropriate directory (according to the question number)
- Handwritten answer for question 2 is in the \answers\ folder
- Question-wise answers are in the \Answers sorted by question\ folder (May have some missing files. If some file is not found, follow the following index)

Question 1.
- 1.2.1., 1.2.2. - Programming Task
- 1.2.3. - Comparison in file \tables\Question 1\Question 1.docx
- 1.3.1. and 1.3.2. - Evalution of whether data is seperable or not in \tables\Question 1\Question 1.docx

Question 2.
- 2.1., 2.2., 2.5. - Answers in \answers\Question 2.pdf
- 2.3. - Programming task
- 2.4. - Contrasting the performance in \tables\Question 2\Unregularized and Regularized.docx 

Question 3.
- 3.1 - Programming Task
	  - 3.1.1. Table in \tables\Question 3\Question_3_1_1.docx and hyper parameters in the \outputs\question3\question3_1_1
	  - 3.1.2. Table in \tables\Question 3\Question_3_1_2.docx and hyper parameters in the \outputs\question3\question3_1_2
	  - Graphs for 3.1.1 and 3.1.2. in \graphs\question3_1_1 and \graphs\question3_1_2 respectively
	  
Question 4.
- 4.1.
	- 4.1.1. Table in \tables\Question 4\Question_4_1_1.docx and hyper parameters in the \outputs\question4\question4_1\
	- 4.1.2. Graphs in \graphs\question4_1\
	- 4.1.3. Output in \outputs\question4\question4_1_3\ and graphs in \graphs\question4_1_3\
	
	
Code
- All code is in the src\ folder.
- Install pipenv
- Install the requirements using 
	``` pipenv install -r requirements.txt ```
- cd into src\ using
	``` cd src ```
- Make the necessary changes in the file (Uncomment the appropriate lines. More instructions in each of the file) and run using
	``` python {filename}.py ```

* Note
 - Make sure you do not change the file structure (or remove files from the submission). My program does not create folders if they're not present and will throw an exception.