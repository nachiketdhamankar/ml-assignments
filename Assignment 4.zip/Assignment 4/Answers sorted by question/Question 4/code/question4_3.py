from util import get_data, create_train_test_list
import numpy as np
import pandas as pd
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, roc_curve, auc
import matplotlib.pyplot as plt


def inner_validation(x_train, y_train, c, gamma, is_linear, m_value=5):
    full_data = pd.DataFrame(np.append(x_train, y_train, 1))
    inner_train_list, inner_test_list = create_train_test_list(data=full_data, n_folds=5)
    accuracy_list = []
    for index in range(m_value):
        train_actual = inner_train_list[index].iloc[:, -1].values
        train_actual.shape = [train_actual.shape[0], 1]
        x_train = inner_train_list[index].iloc[:, :-1].values

        test_actual = inner_test_list[index].iloc[:, -1].values
        test_actual.shape = [test_actual.shape[0], 1]
        x_test = inner_test_list[index].iloc[:, :-1].values
        clf = SVC(C=c, kernel='linear') if is_linear else SVC(C=c, gamma=gamma)
        clf.fit(X=x_train, y=train_actual.ravel())

        curr_score = clf.score(X=x_test, y=test_actual)
        accuracy_list.append(curr_score)
    return np.mean(accuracy_list)


def get_accuracy_recall_precision(actual, predicted, class_id):
    new_actual = actual[np.newaxis]
    new_predicted = predicted[np.newaxis]
    actual = np.transpose(new_actual)
    predicted = np.transpose(new_predicted)
    true_positive = ((actual == class_id) & (predicted == class_id)).sum()
    total_actual_label = (actual == class_id).sum()
    total_predicted_label = (predicted == class_id).sum()
    recall = true_positive / total_actual_label
    precision = true_positive / total_predicted_label
    curr_accuracy_score = accuracy_score(y_true=actual, y_pred=predicted, normalize=False)
    accuracy = curr_accuracy_score / predicted.shape[0]
    return accuracy, recall, precision


def run_kernel(train_data_full, test_data_full, m_value, gamma_list, cost_list, is_linear, unique_classes):
    train_data_full = train_data_full.sample(frac=1).reset_index(drop=True)
    test_data_full = test_data_full.sample(frac=1).reset_index(drop=True)

    train_actual = train_data_full.iloc[:, -1].values
    train_data = train_data_full.iloc[:, :-1].values

    test_actual = test_data_full.iloc[:, -1].values
    test_data = test_data_full.iloc[:, :-1].values

    max_accuracy = float('-inf')
    final_gamma, final_cost = float('-inf'), float('-inf')
    for gamma in gamma_list:
        for cost in cost_list:
            new_train_actual = train_actual[np.newaxis]
            curr_acc = inner_validation(train_data, np.transpose(new_train_actual), cost, gamma, m_value=m_value,
                                        is_linear=is_linear)
            if curr_acc > max_accuracy:
                max_accuracy = curr_acc
                final_cost = cost
                final_gamma = gamma
    print('Final values of gamma: %s and Cost: %s at accuracy of %s' % (final_gamma, final_cost, max_accuracy))
    clf = SVC(C=final_cost, kernel='linear', probability=True) if is_linear else SVC(C=final_cost,
                                                                                     gamma=final_gamma,
                                                                                     probability=True)
    clf.fit(train_data, train_actual)
    train_predicted = clf.predict(train_data)
    test_predicted = clf.predict(test_data)
    curr_probability = clf.predict_proba(test_data)
    for class_id in unique_classes:
        print("Class ID: ", class_id)

        accuracy_train, recall_train, precision_train = get_accuracy_recall_precision(train_actual, train_predicted,
                                                                                      class_id=class_id)
        print("**Train Data**")
        print("Train Accuracy: %s " % accuracy_train)
        print("Train Precision: %s " % precision_train)
        print("Train Recall: %s " % recall_train)

        accuracy_test, recall_test, precision_test = get_accuracy_recall_precision(test_actual, test_predicted,
                                                                                   class_id=class_id)
        print("\n**Test Data**")
        print("Test Accuracy: %s " % accuracy_test)
        print("Test Precision: %s " % precision_test)
        print("Test Recall: %s " % recall_test)

        fpr, tpr, thresholds = roc_curve(y_true=test_actual, y_score=curr_probability[:, class_id], pos_label=class_id)
        roc_auc = auc(fpr, tpr)
        plt.plot(fpr, tpr, alpha=0.3, label='ROC (AUC = %0.2f)' % roc_auc)

        plt.plot([0, 1], [0, 1], 'b--', alpha=.8)
        plt.xlim([-0.05, 1.05])
        plt.ylim([-0.05, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('Receiver Operating Characteristic - Class: %s' % class_id)
        plt.legend(loc="best")
        kernal_name = 'linear' if is_linear else 'RBF'
        plt.savefig('../graphs/question4_1_3/%s/%s.png' % (kernal_name, class_id))
        plt.show()
    print('\n\n')


def run_ocr(gamma_list, cost_list, is_linear):
    train_data = get_data('digits train')
    unique_classes = train_data[len(train_data.columns) - 1].unique()
    test_data = get_data('digits test')
    run_kernel(train_data_full=train_data, test_data_full=test_data, m_value=5, gamma_list=gamma_list,
               cost_list=cost_list, is_linear=is_linear, unique_classes=unique_classes)


if __name__ == '__main__':
    gamma_list = [2 ** i for i in range(-15, 6, 1)]
    cost_list = [2 ** i for i in range(-5, 11, 1)]

    # Change the is_linear flag to False, when you want to run with RBF kernel
    run_ocr(gamma_list=gamma_list, cost_list=cost_list, is_linear=False)
