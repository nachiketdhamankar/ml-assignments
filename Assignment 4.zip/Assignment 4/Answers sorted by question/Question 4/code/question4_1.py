from util import get_data, create_train_test_list, get_mean_stddev, normalize_test_data
import numpy as np
import pandas as pd
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
import statistics
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc


def get_accuracy(actual, predicted, class_list):
    accuracy1, accuracy2, accuracy3 = None, None, None
    for class_id in class_list:
        predicted_per_class = np.equal(predicted, class_id).astype(int)
        actual_per_class = np.equal(actual, class_id).astype(int)
        curr_accuracy_score = accuracy_score(y_true=actual_per_class, y_pred=predicted_per_class, normalize=False)
        if class_id == 1:
            accuracy1 = curr_accuracy_score / predicted.shape[0]
        elif class_id == 2:
            accuracy2 = curr_accuracy_score / predicted.shape[0]
        else:
            accuracy3 = curr_accuracy_score / predicted.shape[0]
    return accuracy1, accuracy2, accuracy3


def inner_validation(x_train, y_train, c, gamma, is_linear, m_value=5):
    full_data = pd.DataFrame(np.append(x_train, y_train, 1))
    inner_train_list, inner_test_list = create_train_test_list(data=full_data, n_folds=5)
    accuracy_list = []
    for index in range(m_value):
        train_actual = inner_train_list[index].iloc[:, -1].values
        train_actual.shape = [train_actual.shape[0], 1]
        x_train = inner_train_list[index].iloc[:, :-1].values

        test_actual = inner_test_list[index].iloc[:, -1].values
        test_actual.shape = [test_actual.shape[0], 1]
        x_test = inner_test_list[index].iloc[:, :-1].values
        clf = SVC(C=c, kernel='linear') if is_linear else SVC(C=c, gamma=gamma)
        clf.fit(X=x_train, y=train_actual.ravel())

        curr_score = clf.score(X=x_test, y=test_actual)
        accuracy_list.append(curr_score)
    return np.mean(accuracy_list)


def get_accuracy_recall_precision(actual, predicted, class_id_list):
    recall_class_1, recall_class_2, recall_class_3, precision_class_1, precision_class_2, precision_class_3 = None, None, None, None, None, None
    for class_id in class_id_list:
        true_positive = ((actual == class_id) & (predicted == class_id)).sum()
        total_actual_label = (actual == class_id).sum()
        total_predicted_label = (predicted == class_id).sum()
        recall = true_positive / total_actual_label
        precision = true_positive / total_predicted_label
        recall = 1 if recall == np.nan else recall
        precision = 1 if precision == np.nan else precision
        if class_id == 1:
            recall_class_1 = recall
            precision_class_1 = precision
        elif class_id == 2:
            recall_class_2 = recall
            precision_class_2 = precision
        else:
            recall_class_3 = recall
            precision_class_3 = precision
    acc1, acc2, acc3 = get_accuracy(actual=actual,
                                    predicted=predicted,
                                    class_list=class_id_list)
    return acc1, acc2, acc3, recall_class_1, recall_class_2, recall_class_3, precision_class_1, precision_class_2, precision_class_3


def run_kernal(data, gamma_list, cost_list, is_linear, unique_classes, k_value=10, m_value=5):
    train_accuracy_list, train_precision_list, train_recall_list = [], [], []
    test_accuracy_list = []
    test_precision_list = []
    test_recall_list = []
    # train_acc_list_1 = [None] * k_value
    # train_acc_list_2 = [None] * k_value
    # train_acc_list_3 = [None] * k_value
    # train_rec_list_1 = [None] * k_value
    # train_rec_list_2 = [None] * k_value
    # train_rec_list_3 = [None] * k_value
    # train_prec_list_1 = [None] * k_value
    # train_prec_list_2 = [None] * k_value
    # train_prec_list_3 = [None] * k_value
    # test_acc_list_1 = [None] * k_value
    # test_acc_list_2 = [None] * k_value
    # test_acc_list_3 = [None] * k_value
    # test_rec_list_1 = [None] * k_value
    # test_rec_list_2 = [None] * k_value
    # test_rec_list_3 = [None] * k_value
    # test_prec_list_1 = [None] * k_value
    # test_prec_list_2 = [None] * k_value
    # test_prec_list_3 = [None] * k_value
    train_acc_list_1 = []
    train_acc_list_2 = []
    train_acc_list_3 = []
    train_rec_list_1 = []
    train_rec_list_2 = []
    train_rec_list_3 = []
    train_prec_list_1 = []
    train_prec_list_2 = []
    train_prec_list_3 = []
    test_acc_list_1 = []
    test_acc_list_2 = []
    test_acc_list_3 = []
    test_rec_list_1 = []
    test_rec_list_2 = []
    test_rec_list_3 = []
    test_prec_list_1 = []
    test_prec_list_2 = []
    test_prec_list_3 = []
    train_list, test_list = create_train_test_list(data)
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(15, 5))
    for index in range(k_value):
        train_actual = train_list[index].iloc[:, -1].values
        train_actual.shape = [train_actual.shape[0], 1]

        normalized_train_data, mean_per_col, stddev_per_col = get_mean_stddev(train_list[index])
        x = normalized_train_data.iloc[:, :-1].values
        train_biased = np.c_[np.ones((len(x), 1)), x]

        test_actual = test_list[index].iloc[:, -1].values
        test_actual.shape = [test_actual.shape[0], 1]
        test_data = normalize_test_data(data=test_list[index], mean_list=mean_per_col, stddev_list=stddev_per_col)
        test = test_data[:, :-1]
        test_biased = np.c_[np.ones((len(test), 1)), test]

        classifiers = []

        for class_id in unique_classes:
            train_predicted_per_class = np.equal(train_actual, class_id).astype(int)
            max_accuracy = float('-inf')
            final_gamma, final_cost = float('-inf'), float('-inf')
            for gamma in gamma_list:
                for cost in cost_list:
                    curr_acc = inner_validation(train_biased, train_actual, cost, gamma, m_value=m_value,
                                                is_linear=is_linear)
                    if curr_acc > max_accuracy:
                        max_accuracy = curr_acc
                        final_cost = cost
                        final_gamma = gamma
            print('Class ID: %s' % class_id)
            print('Values of gamma: %s and Cost: %s at accuracy of %s' % (final_gamma, final_cost, max_accuracy))
            clf = SVC(C=final_cost, kernel='linear', probability=True) if is_linear else SVC(C=final_cost,
                                                                                             gamma=final_gamma,
                                                                                             probability=True)
            clf.fit(X=train_biased, y=train_predicted_per_class.ravel())
            classifiers.append(clf)

        train_predicted = get_predicted(classifiers=classifiers, train_data=train_biased)[np.newaxis]
        new_train_predicted = np.transpose(train_predicted)
        accuracy1, accuracy2, accuracy3, recall_1, recall_2, recall_3, precision_1, precision_2, precision_3 = get_accuracy_recall_precision(
            actual=train_actual, predicted=new_train_predicted,
            class_id_list=unique_classes)
        train_acc_list_1.append(accuracy1)
        train_prec_list_1.append(precision_1)
        train_rec_list_1.append(recall_1)
        train_acc_list_2.append(accuracy2)
        train_prec_list_2.append(precision_2)
        train_rec_list_2.append(recall_2)
        train_acc_list_3.append(accuracy3)
        train_prec_list_3.append(precision_3)
        train_rec_list_3.append(recall_3)
        train_accuracy_list.append(statistics.mean([accuracy1, accuracy2, accuracy3]))
        train_precision_list.append(statistics.mean([precision_1, precision_2, precision_3]))
        train_recall_list.append(statistics.mean([precision_1, precision_2, precision_3]))

        test_predicted = get_predicted(classifiers=classifiers, train_data=test_biased)[np.newaxis]
        new_test_predicted = np.transpose(test_predicted)
        accuracy1, accuracy2, accuracy3, recall_1, recall_2, recall_3, precision_1, precision_2, precision_3 = get_accuracy_recall_precision(
            actual=test_actual, predicted=new_test_predicted,
            class_id_list=unique_classes)
        test_acc_list_1.append(accuracy1)
        test_prec_list_1.append(precision_1)
        test_rec_list_1.append(recall_1)
        test_acc_list_2.append(accuracy2)
        test_prec_list_2.append(precision_2)
        test_rec_list_2.append(recall_2)
        test_acc_list_3.append(accuracy3)
        test_prec_list_3.append(precision_3)
        test_rec_list_3.append(recall_3)
        test_accuracy_list.append(statistics.mean([accuracy1, accuracy2, accuracy3]))
        test_precision_list.append(statistics.mean([precision_1, precision_2, precision_3]))
        test_recall_list.append(statistics.mean([recall_1, recall_2, recall_3]))

        test_probability = get_probability(classifiers=classifiers, data=test_biased)
        for class_id in unique_classes:
            curr_probability = test_probability[:, class_id - 1]
            test_predicted = np.equal(test_actual, class_id).astype(int)
            fpr, tpr, thresholds = roc_curve(test_predicted, curr_probability)
            roc_auc = auc(fpr, tpr)

            if class_id == 1:
                ax1.plot(fpr, tpr, lw=1, alpha=0.3,
                         label='ROC fold %d (AUC = %0.2f), class: %s' % (index + 1, roc_auc, class_id))
            elif class_id == 2:
                ax2.plot(fpr, tpr, lw=1, alpha=0.3,
                         label='ROC fold %d (AUC = %0.2f), class: %s' % (index + 1, roc_auc, class_id))
            else:
                ax3.plot(fpr, tpr, lw=1, alpha=0.3,
                         label='ROC fold %d (AUC = %0.2f), class: %s' % (index + 1, roc_auc, class_id))

    ax1.title.set_text('Class 1')
    ax2.title.set_text('Class 2')
    ax3.title.set_text('Class 3')
    fig.tight_layout()
    for axs in fig.get_axes():
        axs.set_xlim([-0.05, 1.05])
        axs.set_ylim([-0.05, 1.05])
        axs.set_xlabel('False Positive Rate')
        axs.set_ylabel('True Positive Rate')
        axs.legend(loc="best")
        axs.plot([0, 1], [0, 1], 'b--', alpha=.8)
        axs.label_outer()
    kernal_name = 'linear' if is_linear else 'RBF'
    plt.savefig('../graphs/question4_1/%s.png' % kernal_name)
    plt.show()

    print("**Train Data**")
    print("Train Accuracy: %s " % train_accuracy_list)
    print("Train Accuracy Mean: %.5f " % statistics.mean(train_accuracy_list))
    print("Standard Deviation of Train Accuracy across folds: %f " % statistics.stdev(train_accuracy_list))
    print("Train Recall: %s " % train_recall_list)
    print("Train Recall Mean: %.5f " % statistics.mean(train_recall_list))
    print("Standard Deviation of Train Recall across folds: %f " % statistics.stdev(train_recall_list))
    print("Train Precision: %s " % train_precision_list)
    print("Train Precision Mean: %.5f " % statistics.mean(train_precision_list))
    print("Standard Deviation of Train Precision across folds: %f " % statistics.stdev(train_precision_list))

    print("\n\n**Test Data**")
    print("Test Accuracy: %s " % test_accuracy_list)
    print("Test Accuracy Mean: %.5f " % statistics.mean(test_accuracy_list))
    print("Standard Deviation of Test Accuracy across folds: %.5f " % statistics.stdev(test_accuracy_list))
    print("Test Recall: %s " % test_recall_list)
    print("Test Recall Mean: %.5f " % statistics.mean(test_recall_list))
    print("Standard Deviation of Test Recall across folds: %f " % statistics.stdev(test_recall_list))
    print("Test Precision: %s " % test_precision_list)
    print("Test Precision Mean: %.5f " % statistics.mean(test_precision_list))
    print("Standard Deviation of Test Precision across folds: %f " % statistics.stdev(test_precision_list))

    print('\nClass Info\n')
    print('Class: 1')
    print('Train Accuracy: %s' % train_acc_list_1)
    print("Train Accuracy Mean: %.5f " % statistics.mean(train_acc_list_1))
    print("Standard Deviation of Train Accuracy: %f " % statistics.stdev(train_acc_list_1))
    print('Train Recall: %s' % train_rec_list_1)
    print("Train Recall Mean: %.5f " % statistics.mean(train_rec_list_1))
    print("Standard Deviation of Train Recall: %f " % statistics.stdev(train_rec_list_1))
    print('Train Precision: %s' % train_prec_list_1)
    print("Train Precision Mean: %.5f " % statistics.mean(train_prec_list_1))
    print("Standard Deviation of Train Precision: %f " % statistics.stdev(train_prec_list_1))
    print('Test Accuracy: %s' % test_acc_list_1)
    print("Test Accuracy Mean: %.5f " % statistics.mean(test_acc_list_1))
    print("Standard Deviation of Test Accuracy: %f " % statistics.stdev(test_acc_list_1))
    print('Test Recall: %s' % test_rec_list_1)
    print("Test Recall Mean: %.5f " % statistics.mean(test_rec_list_1))
    print("Standard Deviation of Test Recall: %f " % statistics.stdev(test_rec_list_1))
    print('Test Precision: %s' % test_prec_list_1)
    print("Test Precision Mean: %.5f " % statistics.mean(test_prec_list_1))
    print("Standard Deviation of Test Precision: %f " % statistics.stdev(test_prec_list_1))
    print("\n*********\n")
    print('Class: 2')
    print('Train Accuracy: %s' % train_acc_list_2)
    print("Train Accuracy Mean: %.5f " % statistics.mean(train_acc_list_2))
    print("Standard Deviation of Train Accuracy: %f " % statistics.stdev(train_acc_list_2))
    print('Train Recall: %s' % train_rec_list_2)
    print("Train Recall Mean: %.5f " % statistics.mean(train_rec_list_2))
    print("Standard Deviation of Train Recall: %f " % statistics.stdev(train_rec_list_2))
    print('Train Precision: %s' % train_prec_list_2)
    print("Train Precision Mean: %.5f " % statistics.mean(train_prec_list_2))
    print("Standard Deviation of Train Precision: %f " % statistics.stdev(train_prec_list_2))
    print('Test Accuracy: %s' % test_acc_list_2)
    print("Test Accuracy Mean: %.5f " % statistics.mean(test_acc_list_2))
    print("Standard Deviation of Test Accuracy: %f " % statistics.stdev(test_acc_list_2))
    print('Test Recall: %s' % test_rec_list_2)
    print("Test Recall Mean: %.5f " % statistics.mean(test_rec_list_2))
    print("Standard Deviation of Test Recall: %f " % statistics.stdev(test_rec_list_2))
    print('Test Precision: %s' % test_prec_list_2)
    print("Test Precision Mean: %.5f " % statistics.mean(test_prec_list_2))
    print("Standard Deviation of Test Precision: %f " % statistics.stdev(test_prec_list_2))
    print('Class: 3')
    print('Train Accuracy: %s' % train_acc_list_3)
    print("Train Accuracy Mean: %.5f " % statistics.mean(train_acc_list_3))
    print("Standard Deviation of Train Accuracy: %f " % statistics.stdev(train_acc_list_3))
    print('Train Recall: %s' % train_rec_list_3)
    print("Train Recall Mean: %.5f " % statistics.mean(train_rec_list_3))
    print("Standard Deviation of Train Recall: %f " % statistics.stdev(train_rec_list_3))
    print('Train Precision: %s' % train_prec_list_3)
    print("Train Precision Mean: %.5f " % statistics.mean(train_prec_list_3))
    print("Standard Deviation of Train Precision: %f " % statistics.stdev(train_prec_list_3))
    print('Test Accuracy: %s' % test_acc_list_3)
    print("Test Accuracy Mean: %.5f " % statistics.mean(test_acc_list_3))
    print("Standard Deviation of Test Accuracy: %f " % statistics.stdev(test_acc_list_3))
    print('Test Recall: %s' % test_rec_list_3)
    print("Test Recall Mean: %.5f " % statistics.mean(test_rec_list_3))
    print("Standard Deviation of Test Recall: %f " % statistics.stdev(test_rec_list_3))
    print('Test Precision: %s' % test_prec_list_3)
    print("Test Precision Mean: %.5f " % statistics.mean(test_prec_list_3))
    print("Standard Deviation of Test Precision: %f " % statistics.stdev(test_prec_list_3))


def get_probability(classifiers, data):
    probability = np.zeros((len(data), len(classifiers)))
    for index in range(len(classifiers)):
        probability[:, index] = classifiers[index].predict_proba(data)[:, 1]
    return probability


def get_predicted(classifiers, train_data):
    return np.argmax(get_probability(classifiers=classifiers, data=train_data), axis=1) + 1


def run_wine(gamma_list, cost_list, is_linear):
    print('Wine Dataset')
    data = get_data('wine')
    unique_classes = data[0].unique()
    cols = data.columns.tolist()
    cols = cols[1:] + cols[:1]
    new_data = data[cols]
    run_kernal(new_data, k_value=10, m_value=5, gamma_list=gamma_list, cost_list=cost_list, is_linear=is_linear,
               unique_classes=unique_classes)


if __name__ == '__main__':
    gamma_list = [2 ** i for i in range(-15, 6, 1)]
    cost_list = [2 ** i for i in range(-5, 11, 1)]

    # Set value for Linear Kernel and False for RBF Kernel
    run_wine(gamma_list, cost_list, is_linear=True)
