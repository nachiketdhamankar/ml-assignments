from util import get_data, create_train_test_list, get_mean_stddev, normalize_test_data
import numpy as np
import statistics
from sklearn.metrics import accuracy_score
import math


def sigmoid(z):
    return 1 / (1 + np.exp(-z))


def loss(w, x, y):
    sig = sigmoid(x.dot(w))
    cost = -((y * np.log(sig) + (1 - y) * np.log(1 - sig)).mean())
    return cost


def calculate_accuracy(predicted_values, actual_values):
    correct_prediction = predicted_values == actual_values
    accuracy = correct_prediction.sum() / actual_values.size
    return accuracy


def get_recall_precision(actual, predicted, class_id):
    true_positive = ((actual == class_id) & (predicted == class_id)).sum()
    total_actual_label = (actual == class_id).sum()
    total_predicted_label = (predicted == class_id).sum()
    recall = true_positive / total_actual_label
    precision = true_positive / total_predicted_label
    return recall, precision


def predict_evaluate(x, w, actual):
    predicted = np.sign(x.dot(w))
    accuracy = calculate_accuracy(predicted, actual.T)
    recall, precision = get_recall_precision(actual.T, predicted, 1)
    return accuracy, recall, precision


def gradient_descent(x, y, learning_rate, iterations, tolerance, lambda_value=0):
    prev = 0.0
    w_history = []
    loss_list = []
    w = np.zeros((x.shape[1], 1))

    for it in range(iterations):
        prediction = (sigmoid(x.dot(w)) >= 0.5).astype('int')

        test_val = np.hstack([[0], w[:, 0]])[np.newaxis]
        new = test_val[:, w.size].T
        grad_new = lambda_value * new + (x.T.dot(prediction - y))

        w = w - learning_rate * grad_new
        curr_loss = loss(w, x, y)
        if math.isclose(prev, curr_loss, abs_tol=tolerance):
            break
        w_history.append(list(w.T))
        prev = curr_loss
        loss_list.append(curr_loss)

    return w, w_history, loss_list


def regression(data, learning_rate=0.0001, num_iter=10000, tolerance=0.001, lambda_value=10):
    n_folds = 10
    train_list, test_list = create_train_test_list(data)

    train_loss, train_sse = [], []
    test_accuracy_list, train_accuracy_list = [], []
    total_loss_list = []
    train_recall_list, train_prec_list = [], []
    test_precision_list, test_recall_list = [], []
    for index in range(n_folds):
        train_actual = train_list[index].iloc[:, -1].values
        train_actual.shape = [train_actual.shape[0], 1]

        normalized__train_data, mean_per_col, stddev_per_col = get_mean_stddev(train_list[index])

        x = normalized__train_data.iloc[:, :-1].values
        y = train_actual
        y.shape = [y.shape[0], 1]
        x_biased = np.c_[np.ones((len(x), 1)), x]

        w, w_history, loss_list = gradient_descent(x_biased, y, learning_rate, num_iter, tolerance,
                                                   lambda_value=lambda_value)
        curr_loss = loss_list

        train_pred = (sigmoid(x_biased.dot(w)) >= 0.5).astype('int')

        curr_train_acc_score = accuracy_score(train_actual, train_pred, normalize=False)
        curr_train_acc = curr_train_acc_score / train_pred.shape[0]
        curr_train_recall, curr_train_precision = get_recall_precision(train_actual, train_pred, class_id=1)
        train_accuracy_list.append(curr_train_acc)
        train_recall_list.append(curr_train_recall)
        train_prec_list.append(curr_train_precision)
        train_loss.append(statistics.mean(curr_loss))

        curr_test_acc, curr_test_recall, curr_test_precision = get_test_accuracy_recall_precision(w=w,
                                                                                                  data=test_list[index],
                                                                                                  mean_list=mean_per_col,
                                                                                                  stddev_list=stddev_per_col)

        test_accuracy_list.append(curr_test_acc)
        test_recall_list.append(curr_test_recall)
        test_precision_list.append(curr_test_precision)
        total_loss_list.append(loss_list)

    print("**Train Data**")
    print("Train Accuracy: %s " % train_accuracy_list)
    print("Train Accuracy Mean: %.5f " % statistics.mean(train_accuracy_list))
    print("Standard Deviation of Train Accuracy across folds: %f " % statistics.stdev(train_accuracy_list))
    print("Train Recall: %s " % train_recall_list)
    print("Train Recall Mean: %.5f " % statistics.mean(train_recall_list))
    print("Standard Deviation of Train Recall across folds: %f " % statistics.stdev(train_recall_list))
    print("Train Precision: %s " % train_prec_list)
    print("Train Precision Mean: %.5f " % statistics.mean(train_prec_list))
    print("Standard Deviation of Train Precision across folds: %f " % statistics.stdev(train_prec_list))

    print("\n\n**Test Data**")
    print("Test Accuracy: %s " % test_accuracy_list)
    print("Test Accuracy Mean: %.5f " % statistics.mean(test_accuracy_list))
    print("Standard Deviation of Test Accuracy across folds: %.5f " % statistics.stdev(test_accuracy_list))
    print("Test Recall: %s " % test_recall_list)
    print("Test Recall Mean: %.5f " % statistics.mean(test_recall_list))
    print("Standard Deviation of Test Recall across folds: %f " % statistics.stdev(test_recall_list))
    print("Test Precision: %s " % test_precision_list)
    print("Test Precision Mean: %.5f " % statistics.mean(test_precision_list))
    print("Standard Deviation of Test Precision across folds: %f " % statistics.stdev(test_precision_list))


def test_predict_evaluate(w, data, mean_list, stddev_list):
    actual = data.iloc[:, -1].values
    actual.shape = [actual.shape[0], 1]
    test_data = normalize_test_data(data=data, mean_list=mean_list, stddev_list=stddev_list)
    test = test_data[:, :-1]
    test_biased = np.c_[np.ones((len(test), 1)), test]
    return predict_evaluate(x=test_biased, w=w, actual=actual)


def get_test_accuracy_recall_precision(w, data, mean_list, stddev_list):
    actual = data.iloc[:, -1].values
    actual.shape = [actual.shape[0], 1]
    test_data = normalize_test_data(data=data, mean_list=mean_list, stddev_list=stddev_list)
    test = test_data[:, :-1]
    test_biased = np.c_[np.ones((len(test), 1)), test]
    predictions = sigmoid(test_biased.dot(w))
    new_pred = (predictions >= 0.5).astype('int')
    accuracy = np.mean(new_pred == actual)
    recall, precision = get_recall_precision(actual=actual, predicted=new_pred, class_id=1)
    return accuracy, recall, precision


def run_breast_cancer(lambda_value):
    print('Breast Cancer Dataset with Normalization, lambda=' + str(lambda_value))
    data = get_data('breastcancer')
    regression(data, learning_rate=0.0025, num_iter=150, tolerance=0.000001, lambda_value=lambda_value)


def run_spambase(lambda_value):
    print('Spambase Dataset with Normalization, lambda=' + str(lambda_value))
    data = get_data('spambase')
    regression(data, learning_rate=0.0005, num_iter=2500, tolerance=0.0000001, lambda_value=lambda_value)


def run_diabetes(lambda_value):
    print('Diabetes Dataset with Normalization, lambda=' + str(lambda_value))
    data = get_data('diabetes')
    regression(data, learning_rate=0.001, num_iter=500, tolerance=0.000004, lambda_value=lambda_value)


if __name__ == '__main__':
    """
    The main function.
    To run the model for the dataset, uncomment the dataset you want to run.
    If you want to change the parameters, change them in run_{dataset_name}() function.
    """
    # Uncomment to display all columns
    # pd.set_option('display.max_rows', 500)
    # pd.set_option('display.max_columns', 500)
    # pd.set_option('display.width', 1000)

    # Uncomment appropriate dataset and add the required lambda_value
    # Perform a grid search for lambda to be in [10, 50, 100, 500]
    for power in range(1, 3, 1):
        for multiple in [1, 5]:
            lambda_value = (10 ** power * multiple)
            # run_diabetes(lambda_value=lambda_value)
            # run_breast_cancer(lambda_value=lambda_value)
            run_spambase(lambda_value=lambda_value)
