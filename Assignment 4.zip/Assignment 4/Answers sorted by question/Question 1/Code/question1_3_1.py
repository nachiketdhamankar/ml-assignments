import pandas as pd
import numpy as np
from util import create_train_test_list, get_mean_stddev, normalize_test_data
import statistics


def get_data(dataset_name):
    file_name = "../dataset/" + dataset_name + ".csv"
    data = pd.read_csv(file_name, header=None)
    return data


class dual_perceptron_class():
    def __init__(self, max_epoch, learning_rate):
        self.max_epoch = max_epoch
        self.learning_rate = learning_rate

    def run_model(self, x, y_actual):
        alpha = np.zeros(y_actual.size)
        epoch = 0
        while epoch <= self.max_epoch:
            should_epoch_continue = False
            for index in range(len(x)):
                alpha, was_wrong_prediction = self.dual_perceptron(x, y_actual, index, alpha)
                if was_wrong_prediction == True and should_epoch_continue == False:
                    # print('Some prediction was wrong. Continue to next epoch')
                    should_epoch_continue = True
            epoch += 1
            # print('Running epoch: ' + str(epoch))
            if not should_epoch_continue:
                break
        # print('It took the program ' + str(epoch) + ' epochs')
        return np.transpose(alpha)

    def dual_perceptron(self, x, y, index, alpha):
        y = np.transpose(y)
        kernal = x.dot(x[index])
        y_predicted = np.sign((alpha * y * kernal).sum())
        is_wrong_prediction = False
        if y[:, index] * y_predicted <= 0:
            alpha[index] += 1
            is_wrong_prediction = True
        return alpha, is_wrong_prediction


def run_perceptron(data, n_folds, model=None):
    train_list, test_list = create_train_test_list(data)
    # n_folds = 1
    recall_train_list, accuracy_train_list, precision_train_list = [], [], []
    recall_test_list, accuracy_test_list, precision_test_list = [], [], []
    for index in range(n_folds):
        train_actual = train_list[index].iloc[:, -1].values
        train_actual.shape = [train_actual.shape[0], 1]
        test_actual = test_list[index].iloc[:, -1].values
        test_actual.shape = [test_actual.shape[0], 1]

        normalized__train_data, mean_per_col, stddev_per_col = get_mean_stddev(train_list[index])

        x = normalized__train_data.iloc[:, :-1].values
        y = train_actual
        y.shape = [y.shape[0], 1]
        x_biased = np.c_[np.ones((len(x), 1)), x]

        test_actual = test_list[index].iloc[:, -1].values
        test_actual.shape = [test_actual.shape[0], 1]
        test_data = normalize_test_data(data=test_list[index], mean_list=mean_per_col, stddev_list=stddev_per_col)
        test = test_data[:, :-1]
        test_biased = np.c_[np.ones((len(test), 1)), test]

        w = model.run_model(x_biased, y)
        # print('Final w: %s' % w)

        accuracy, recall, precision = predict_evaluate(x_biased, w, train_actual)
        accuracy_train_list.append(accuracy)
        recall_train_list.append(recall)
        precision_train_list.append(precision)

        accuracy, recall, precision = predict_evaluate(test_biased, w, test_actual)

        accuracy_test_list.append(accuracy)
        recall_test_list.append(recall)
        precision_test_list.append(precision)

    print("**Train Data**")
    print("Train Accuracy: %s " % accuracy_train_list)
    print("Train Accuracy Mean: %.5f " % statistics.mean(accuracy_train_list))
    print("Standard Deviation of Train Accuracy across folds: %f " % statistics.stdev(accuracy_train_list))
    print("Train Recall: %s " % recall_train_list)
    print("Train Recall Mean: %.5f " % statistics.mean(recall_train_list))
    print("Standard Deviation of Train Recall across folds: %f " % statistics.stdev(recall_train_list))
    print("Train Precision: %s " % precision_train_list)
    print("Train Precision Mean: %.5f " % statistics.mean(precision_train_list))
    print("Standard Deviation of Train Precision across folds: %f " % statistics.stdev(precision_train_list))

    print("\n\n**Test Data**")
    print("Test Accuracy: %s " % accuracy_test_list)
    print("Test Accuracy Mean: %.5f " % statistics.mean(accuracy_test_list))
    print("Standard Deviation of Test Accuracy across folds: %f " % statistics.stdev(accuracy_test_list))
    print("Test Recall: %s " % recall_test_list)
    print("Test Recall Mean: %.5f " % statistics.mean(recall_test_list))
    print("Standard Deviation of Test Recall across folds: %f " % statistics.stdev(recall_test_list))
    print("Test Precision: %s " % precision_test_list)
    print("Test Precision Mean: %.5f " % statistics.mean(precision_test_list))
    print("Standard Deviation of Test Precision across folds: %f " % statistics.stdev(precision_test_list))


def test_predict_evaluate(w, test_data, mean_list, stddev_list):
    test_actual = test_data.iloc[:, -1].values
    test_actual.shape = [test_actual.shape[0], 1]
    test_data = normalize_test_data(data=test_data, mean_list=mean_list, stddev_list=stddev_list)
    test = test_data[:, :-1]
    test_biased = np.c_[np.ones((len(test), 1)), test]
    return predict_evaluate(x=test_biased, w=w, actual=test_actual)


def dual_predict(X, y, Xi, alpha):
    kernal = X.dot(Xi)
    y = np.transpose(y)
    s = (alpha * y * kernal).sum()
    y_hat_i = np.sign(s)

    return y_hat_i


def predict_evaluate(x, w, actual):
    predicted = np.zeros(x.shape[0])
    w.shape = [w.shape[0], 1]
    for i in range(predicted.size):
        predicted[i] = dual_predict(x, actual, x[i], w)
    accuracy = calculate_accuracy(predicted, actual.T)
    recall, precision = get_recall_precision(actual.T, predicted, 1)
    return accuracy, recall, precision


def calculate_accuracy(predicted_values, actual_values):
    correct_prediction = predicted_values == actual_values
    accuracy = correct_prediction.sum() / actual_values.size
    return accuracy


def get_recall_precision(actual, predicted, class_id):
    true_positive = ((actual == class_id) & (predicted == class_id)).sum()
    total_actual_label = (actual == class_id).sum()
    total_predicted_label = (predicted == class_id).sum()
    recall = true_positive / total_actual_label
    precision = true_positive / total_predicted_label
    return recall, precision


def two_spiral():
    data = get_data('twoSpirals')
    run_perceptron(data=data, n_folds=10, model=dual_perceptron_class(max_epoch=1000, learning_rate=1))


if __name__ == '__main__':
    two_spiral()
