from util import get_data, create_train_test_list, get_mean_stddev, normalize_test_data
import numpy as np
import pandas as pd
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, roc_auc_score
import statistics
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc


def get_accuracy_recall_precision(actual, predicted, class_id=1):
    true_positive = ((actual == class_id) & (predicted == class_id)).sum()
    total_actual_label = (actual == class_id).sum()
    total_predicted_label = (predicted == class_id).sum()
    recall = true_positive / total_actual_label
    precision = true_positive / total_predicted_label
    curr_accuracy_score = accuracy_score(y_true=actual, y_pred=predicted, normalize=False)
    accuracy = curr_accuracy_score / predicted.shape[0]
    return accuracy, recall, precision


def inner_validation(x_train, y_train, c, gamma, is_linear, m_value=5):
    full_data = pd.DataFrame(np.append(x_train, y_train, 1))
    inner_train_list, inner_test_list = create_train_test_list(data=full_data, n_folds=5)
    auc_score_list = []
    for index in range(m_value):
        train_actual = inner_train_list[index].iloc[:, -1].values
        train_actual.shape = [train_actual.shape[0], 1]
        x_train = inner_train_list[index].iloc[:, :-1].values

        test_actual = inner_test_list[index].iloc[:, -1].values
        test_actual.shape = [test_actual.shape[0], 1]
        x_test = inner_test_list[index].iloc[:, :-1].values
        clf = SVC(C=c, kernel='linear', probability=True) if is_linear else SVC(C=c, gamma=gamma, probability=True)
        clf.fit(X=x_train, y=train_actual.ravel())

        predicted_class_prob = clf.predict_proba(x_train)
        prob_score = predicted_class_prob[:, 1]
        curr_score = roc_auc_score(y_true=train_actual, y_score=prob_score)
        auc_score_list.append(curr_score)
    return np.mean(auc_score_list)


def run_kernal(data, gamma_list, cost_list, is_linear, k_value=10, m_value=5, dataset_name=None):
    train_accuracy_list, train_precision_list, train_recall_list = [], [], []
    test_accuracy_list = []
    test_precision_list = []
    test_recall_list = []

    train_list, test_list = create_train_test_list(data)
    for index in range(k_value):
        train_actual = train_list[index].iloc[:, -1].values
        train_actual.shape = [train_actual.shape[0], 1]

        normalized_train_data, mean_per_col, stddev_per_col = get_mean_stddev(train_list[index])
        x = normalized_train_data.iloc[:, :-1].values
        train_biased = np.c_[np.ones((len(x), 1)), x]

        test_actual = test_list[index].iloc[:, -1].values
        test_actual.shape = [test_actual.shape[0], 1]
        test_data = normalize_test_data(data=test_list[index], mean_list=mean_per_col, stddev_list=stddev_per_col)
        test = test_data[:, :-1]
        test_biased = np.c_[np.ones((len(test), 1)), test]

        max_auc_score = float('-inf')
        final_gamma, final_cost = float('-inf'), float('-inf')
        for gamma in gamma_list:
            for cost in cost_list:
                curr_auc_score = inner_validation(train_biased, train_actual, cost, gamma, m_value=m_value,
                                                  is_linear=is_linear)
                if curr_auc_score > max_auc_score:
                    max_auc_score = curr_auc_score
                    final_cost = cost
                    final_gamma = gamma

        print('Fold %s, values of gamma: %s and Cost: %s at AUC Score of %s' % (
            index, final_gamma, final_cost, max_auc_score))
        clf = SVC(C=final_cost, kernel='linear', probability=True) if is_linear else SVC(C=final_cost,
                                                                                         gamma=final_gamma,
                                                                                         probability=True)
        clf.fit(X=train_biased, y=train_actual.ravel())
        train_predicted = clf.predict(X=train_biased)[np.newaxis]
        new_train_predicted = np.transpose(train_predicted)
        accuracy, recall, precision = get_accuracy_recall_precision(actual=train_actual, predicted=new_train_predicted,
                                                                    class_id=1)
        train_accuracy_list.append(accuracy)
        train_precision_list.append(precision)
        train_recall_list.append(recall)

        test_predicted = clf.predict(X=test_biased)[np.newaxis]
        new_test_predicted = np.transpose(test_predicted)
        accuracy, recall, precision = get_accuracy_recall_precision(actual=test_actual, predicted=new_test_predicted,
                                                                    class_id=1)

        test_accuracy_list.append(accuracy)
        test_precision_list.append(precision)
        test_recall_list.append(recall)

        probas_ = clf.predict_proba(test_biased)
        fpr, tpr, thresholds = roc_curve(test_actual, probas_[:, 1])
        roc_auc = auc(fpr, tpr)
        plt.plot(fpr, tpr, lw=1, alpha=0.3, label='ROC fold %d (AUC = %0.2f)' % (index + 1, roc_auc))

    _dataset_name = dataset_name if dataset_name else ''
    plt.title('Receiver Operating Characteristic - %s' % _dataset_name)
    plt.plot([0, 1], [0, 1], 'b--', alpha=.8)
    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.legend(loc="best")
    kernal_name = 'linear' if is_linear else 'RBF'
    _file_name = '' if not dataset_name else dataset_name
    plt.savefig('../graphs/question3_1_2/%s/%s.png' % (kernal_name, dataset_name))
    plt.show()

    print("**Train Data**")
    print("Train Accuracy: %s " % train_accuracy_list)
    print("Train Accuracy Mean: %.5f " % statistics.mean(train_accuracy_list))
    print("Standard Deviation of Train Accuracy across folds: %f " % statistics.stdev(train_accuracy_list))
    print("Train Recall: %s " % train_recall_list)
    print("Train Recall Mean: %.5f " % statistics.mean(train_recall_list))
    print("Standard Deviation of Train Recall across folds: %f " % statistics.stdev(train_recall_list))
    print("Train Precision: %s " % train_precision_list)
    print("Train Precision Mean: %.5f " % statistics.mean(train_precision_list))
    print("Standard Deviation of Train Precision across folds: %f " % statistics.stdev(train_precision_list))

    print("\n\n**Test Data**")
    print("Test Accuracy: %s " % test_accuracy_list)
    print("Test Accuracy Mean: %.5f " % statistics.mean(test_accuracy_list))
    print("Standard Deviation of Test Accuracy across folds: %.5f " % statistics.stdev(test_accuracy_list))
    print("Test Recall: %s " % test_recall_list)
    print("Test Recall Mean: %.5f " % statistics.mean(test_recall_list))
    print("Standard Deviation of Test Recall across folds: %f " % statistics.stdev(test_recall_list))
    print("Test Precision: %s " % test_precision_list)
    print("Test Precision Mean: %.5f " % statistics.mean(test_precision_list))
    print("Standard Deviation of Test Precision across folds: %f " % statistics.stdev(test_precision_list))


def run_diabetes(gamma_list, cost_list, is_linear):
    print('Diabetes Dataset')
    data = get_data('diabetes')
    run_kernal(data, k_value=10, m_value=5, gamma_list=gamma_list, cost_list=cost_list, is_linear=is_linear,
               dataset_name='Diabetes')


def run_spambase(gamma_list, cost_list, is_linear):
    _name = 'linear' if is_linear else 'RBF'
    print('Spambase Dataset %s' % _name)
    data = get_data('spambase')
    run_kernal(data, k_value=10, m_value=5, gamma_list=gamma_list, cost_list=cost_list, is_linear=is_linear,
               dataset_name='Spambase')


def run_breast_cancer(gamma_list, cost_list, is_linear):
    print('Breast Cancer Dataset')
    data = get_data('breastcancer')
    run_kernal(data, k_value=10, m_value=5, gamma_list=gamma_list, cost_list=cost_list, is_linear=is_linear,
               dataset_name='Breast Cancer')


if __name__ == '__main__':
    gamma_list = [2 ** i for i in range(-8, 2, 1)]
    cost_list = [2 ** i for i in range(-1, 6, 1)]

    # Comment/Uncomment the datasets for which you want to run the model.
    # Set the flag 'is_linear' to False when you want to run RBF kernal and True when you want to run Linear kernel

    # run_diabetes(gamma_list, cost_list, is_linear=True)
    # run_breast_cancer(gamma_list, cost_list, is_linear=True)
    run_spambase(gamma_list, cost_list, is_linear=True)
