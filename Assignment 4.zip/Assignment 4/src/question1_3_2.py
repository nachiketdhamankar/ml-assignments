import numpy as np
import statistics
from util import create_train_test_list, get_data


class dual_perceptron_rbf_class(object):
    def __init__(self, gamma, max_epoch):
        self.max_epoch = max_epoch
        self.gamma = gamma

    def kernel(self, x, y):
        difference = x - y
        result = np.exp(-self.gamma * difference.dot(difference))
        return result

    def run_model(self, x, y_actual):
        self.alpha = np.zeros(x.shape[0])
        k_matrix = np.zeros((x.shape[0], x.shape[0]))

        for row in range(x.shape[0]):
            for col in range(x.shape[0]):
                k_matrix[row, col] = self.kernel(x[row], x[col])

        for iter in range(int(np.ceil(self.max_epoch / len(y_actual)))):
            for row in range(x.shape[0]):
                if np.sign(np.sum(k_matrix[:, row] * self.alpha * y_actual)) != y_actual[row]:
                    self.alpha[row] += 1.0

        support_vector_bool = self.alpha >= 0.000001
        self.alpha = self.alpha[support_vector_bool]
        self.support_vector_x = x[support_vector_bool]
        self.support_vector_y = y_actual[support_vector_bool]

    def predict(self, x):
        temp_matrix = np.zeros(len(x))
        for row in range(len(x)):
            curr_sum = 0
            for curr_alpha, curr_support_vector_y, curr_support_vector_x in zip(self.alpha, self.support_vector_y,
                                                                                self.support_vector_x):
                curr_sum += curr_alpha * curr_support_vector_y * self.kernel(x[row], curr_support_vector_x)
            temp_matrix[row] = curr_sum
        return np.sign(temp_matrix)


def calculate_accuracy(predicted_values, actual_values):
    correct_prediction = predicted_values == actual_values
    accuracy = correct_prediction.sum() / actual_values.size
    return accuracy


def evaluate(predicted, actual):
    accuracy = calculate_accuracy(predicted, actual)
    recall, precision = get_recall_precision(actual, predicted, 1)
    return accuracy, recall, precision


def get_recall_precision(actual, predicted, class_id):
    true_positive = ((actual == class_id) & (predicted == class_id)).sum()
    total_actual_label = (actual == class_id).sum()
    total_predicted_label = (predicted == class_id).sum()
    recall = true_positive / total_actual_label
    precision = true_positive / total_predicted_label
    return recall, precision


def run_perceptron(data, n_folds, model):
    train_list, test_list = create_train_test_list(data)
    recall_train_list, accuracy_train_list, precision_train_list = [], [], []
    recall_test_list, accuracy_test_list, precision_test_list = [], [], []
    for index in range(n_folds):
        train_actual = train_list[index].iloc[:, -1].values
        train_actual.shape = [train_actual.shape[0], 1]
        test_actual = test_list[index].iloc[:, -1].values
        test_actual.shape = [test_actual.shape[0], 1]

        x = train_list[index].iloc[:, :-1].values
        y = np.transpose(train_actual).flatten()

        model.run_model(x, y)

        train_predicted = model.predict(x)[np.newaxis]

        accuracy, precision, recall = evaluate(train_actual, np.transpose(train_predicted))
        accuracy_train_list.append(accuracy)
        recall_train_list.append(recall)
        precision_train_list.append(precision)

        x_test = test_list[index].iloc[:, :-1].values
        test_predicted = model.predict(x_test)[np.newaxis]

        accuracy, precision, recall = evaluate(test_actual, np.transpose(test_predicted))
        accuracy_test_list.append(accuracy)
        recall_test_list.append(recall)
        precision_test_list.append(precision)

    print("**Train Data**")
    print("Train Accuracy: %s " % accuracy_train_list)
    print("Train Accuracy Mean: %.5f " % statistics.mean(accuracy_train_list))
    print("Standard Deviation of Train Accuracy across folds: %f " % statistics.stdev(accuracy_train_list))
    print("Train Recall: %s " % recall_train_list)
    print("Train Recall Mean: %.5f " % statistics.mean(recall_train_list))
    print("Standard Deviation of Train Recall across folds: %f " % statistics.stdev(recall_train_list))
    print("Train Precision: %s " % precision_train_list)
    print("Train Precision Mean: %.5f " % statistics.mean(precision_train_list))
    print("Standard Deviation of Train Precision across folds: %f " % statistics.stdev(precision_train_list))

    print("\n\n**Test Data**")
    print("Test Accuracy: %s " % accuracy_test_list)
    print("Test Accuracy Mean: %.5f " % statistics.mean(accuracy_test_list))
    print("Standard Deviation of Test Accuracy across folds: %f " % statistics.stdev(accuracy_test_list))
    print("Test Recall: %s " % recall_test_list)
    print("Test Recall Mean: %.5f " % statistics.mean(recall_test_list))
    print("Standard Deviation of Test Recall across folds: %f " % statistics.stdev(recall_test_list))
    print("Test Precision: %s " % precision_test_list)
    print("Test Precision Mean: %.5f " % statistics.mean(precision_test_list))
    print("Standard Deviation of Test Precision across folds: %f " % statistics.stdev(precision_test_list))


def run_two_spiral_rbf(gamma_list):
    data = get_data('twoSpirals')
    for gamma in gamma_list:
        print('Dual Perceptron RBF: gamma = %s' % gamma)
        run_perceptron(data=data, n_folds=10, model=dual_perceptron_rbf_class(gamma=gamma, max_epoch=20000))


if __name__ == '__main__':
    gammas = [0.01, 0.05, 0.1, 0.15, 0.2, 0.25]
    run_two_spiral_rbf(gammas)
