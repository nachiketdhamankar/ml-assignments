- Navigate to the folder 'Code' (which has the requirements.txt)
- Make sure you have a folder 'plots' that is in the same directory as the 'src' folder.
- Install pipenv and make sure it's working
- Run the command ``` pipenv install -r requirements.txt```
- Start the virtual environment by ``` pipenv shell ```

- Navigate to the 'src' folder using ```cd src```

	- Question 2 commands - 
		* For housing 
			``` python question2.py -h ```
		* For Yacht
			``` python question2.py -y ```
		* For Concrete
			``` python question2.py -c ```
		* For All 3
			``` python question2.py -a ```
	
	- Question 3 commands - 
		* For housing 
			``` python question3.py -h ```
		* For Yacht
			``` python question3.py -y ```
		* For Concrete
			``` python question3.py -c ```
		* For All 3
			``` python question3.py -a ```
	
	- Question 5 commands -
		* For Sin 
			``` python question5_sin.py ```
		
		* For Yacht 
			``` python question5_yacht.py ```
			
	- Question 7 commands - 
		* When p=5
			``` python question7.py -p 5 ```
		
		* When p=9
			``` python question7.py -p 9 ```
