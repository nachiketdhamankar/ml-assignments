import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def get_test_rmse_with_bias(w, test_data):
    actual = test_data[:, -1]
    actual.shape = [actual.shape[0], 1]
    test = test_data[:, :-1]
    test_biased = np.c_[np.ones((len(test), 1)), test]
    w.shape = [w.shape[0], 1]
    rmse = calculate_rmse(w=w, x=test_biased, y=actual)
    return rmse


def get_new_test_rmse_with_bias(w, data, mean_list, stddev_list):
    test_data = normalize_test_data(data, mean_list, stddev_list)
    actual = test_data[:, -1]
    actual.shape = [actual.shape[0], 1]
    test = test_data[:, :-1]
    test_biased = np.c_[np.ones((len(test), 1)), test]
    w.shape = [w.shape[0], 1]
    rmse = calculate_rmse(w=w, x=test_biased, y=actual)
    return rmse


def normalize_test_data(data, mean_list, stddev_list):
    index = 0
    for col in data.columns:
        new_col = str(col) + 'z_norm'
        col_mean = mean_list[index]
        col_stddev = stddev_list[index]
        index += 1
        data[new_col] = (data[col] - col_mean) / col_stddev
        data.drop(columns=[col], inplace=True)
    data.columns = range(data.shape[1])
    return data.values


def new_get_test_rmse(w, data, mean_list, stddev_list):
    test_data = normalize_test_data(data, mean_list, stddev_list)
    actual = test_data[:, -1]
    actual.shape = [actual.shape[0], 1]
    test = test_data[:, :-1]
    test_biased = np.c_[np.ones((len(test), 1)), test]
    final_w = w[0]
    final_w.shape = [final_w.shape[0], 1]
    rmse = calculate_rmse(w=final_w, x=test_biased, y=actual)
    return rmse


def get_test_rmse_without_bias(w, test_data):
    actual = test_data[:, -1]
    actual.shape = [actual.shape[0], 1]
    test = test_data[:, :-1]
    w.shape = [w.shape[0], 1]
    rmse = calculate_rmse(w=w, x=test, y=actual)
    return rmse


def get_data_without_normalize(dataset_name):
    file_name = "../dataset/" + dataset_name + ".csv"
    data = pd.read_csv(file_name, header=None)
    return data


def add_power(power, data):
    if power < 2:
        return data
    for i in range(2, power + 1, 1):
        values_with_power = data[0] ** i
        data.insert(loc=len(data.columns) - 1, column='^' + str(len(data.columns)), value=values_with_power)
    return data


def plot_graph(rmse, label, index=1):
    y_plot_data = np.array(rmse)
    x_plot_data = np.arange(y_plot_data.size)

    fig, ax = plt.subplots()
    ax.plot(x_plot_data, y_plot_data, 'r.-')

    ax.set(xlabel='No. of Iterations', ylabel='RMSE')
    plt.title(str(label) + ' - Fold: ' + str(index + 1))
    plt.savefig('')
    plt.show()


def z_score_normalize(data):
    for col in data.columns:
        new_col = str(col) + 'z_norm'
        data[new_col] = (data[col] - data[col].mean()) / data[col].std(ddof=0)
        data.drop(columns=[col], inplace=True)
    data.columns = range(data.shape[1])
    return data


def calculate_rmse(w, x, y):
    predictions = x.dot(w)
    return np.sqrt(np.mean((predictions - y) ** 2))


def get_normalized_data(dataset_name):
    file_name = "../dataset/" + dataset_name + ".csv"
    data = pd.read_csv(file_name, header=None)
    return z_score_normalize(data)


def print_dataset_name(name):
    print("*************************")
    print(name)
    print("*************************")


def check_for_nan(data):
    if data.isnull().sum().sum() != 0:
        raise Exception("NaN values present.")


def calculate_sse(w, x, y):
    predictions = x.dot(w)
    return np.sum((predictions - y) ** 2)


def get_mean_stddev(data):
    mean_list, stddev_list = [], []
    for col in data.columns:
        new_col = str(col) + 'z_norm'
        col_mean = data[col].mean()
        col_stddev = data[col].std(ddof=0)
        mean_list.append(col_mean)
        stddev_list.append(col_stddev)
        data[new_col] = (data[col] - col_mean) / col_stddev
        data.drop(columns=[col], inplace=True)
    data.columns = range(data.shape[1])

    return data, mean_list, stddev_list


def create_train_test_list(data):
    df = data.sample(frac=1).reset_index(drop=True)
    train_data, test_data = [], []
    n_folds = 10
    dfList = np.array_split(df, n_folds)
    for x in range(n_folds):
        trainList = []
        for y in range(n_folds):
            if y == x:
                testdf = dfList[y]
            else:
                trainList.append(dfList[y])
        traindf = pd.concat(trainList)
        train_data.append(traindf)
        test_data.append(testdf)
    return train_data, test_data
