from util import create_train_test_list, calculate_rmse, calculate_sse, \
    print_dataset_name, get_data_without_normalize, get_mean_stddev, new_get_test_rmse

import matplotlib.pyplot as plt
import sys
import numpy as np
import statistics
import math
import random


def plot_graph(rmse, label, index=1):
    y_plot_data = np.array(rmse)
    x_plot_data = np.arange(y_plot_data.size)

    fig, ax = plt.subplots()
    ax.plot(x_plot_data, y_plot_data, 'r.-')

    ax.set(xlabel='No. of Iterations', ylabel='RMSE')
    plt.title(str(label) + ' - Fold: ' + str(index + 1))
    plt.savefig('../plots/question_1_' + str(label) + '.png')
    plt.show()


def gradient_descent(x, y, w, learning_rate, iterations, tolerance):
    cost_history = np.zeros(iterations)
    prev = 0.0
    w_history = []
    rmse, sse = [], []
    for it in range(iterations):
        prediction = np.dot(x, w)

        w = w - learning_rate * x.T.dot(prediction - y)
        curr_cost = calculate_rmse(w, x, y)
        if math.isclose(prev, curr_cost, abs_tol=tolerance):
            break
        w_history.append(list(w.T))
        cost_history[it] = curr_cost
        prev = curr_cost
        rmse.append(curr_cost)
        curr_sse = calculate_sse(w=w, x=x, y=y)
        sse.append(curr_sse)

    return w_history[-1], cost_history, w_history, rmse, sse


def run_gradient_descent(data, learning_rate, tolerence, num_iter, label="Graph"):
    n_folds = 10
    train_list, test_list = create_train_test_list(data)
    train_rmse, train_sse = [], []
    test_rmse, test_sse = [], []
    rand_fold = random.randint(1, n_folds - 1)
    for index in range(n_folds):
        normalized__train_data, mean_per_col, stddev_per_col = get_mean_stddev(train_list[index])

        # x = train_list[index].iloc[:, :-1].values
        # y = train_list[index].iloc[:, -1].values
        x = normalized__train_data.iloc[:, :-1].values
        y = normalized__train_data.iloc[:, -1].values
        y.shape = [y.shape[0], 1]

        x_biased = np.c_[np.ones((len(x), 1)), x]
        w = np.zeros((x_biased.shape[1], 1))

        w, cost_history, w_history, rmse, sse = gradient_descent(x_biased, y, w, learning_rate, num_iter,
                                                                 tolerence)

        train_rmse.append(statistics.mean(rmse))
        train_sse.append(statistics.mean(sse))

        # test_rmse_val = get_test_rmse(w=w, test_data=test_list[index].values)
        test_rmse_val = new_get_test_rmse(w=w, data=test_list[index], mean_list=mean_per_col,
                                          stddev_list=stddev_per_col)
        test_rmse.append(test_rmse_val)

        if index == rand_fold:
            plot_graph(rmse=rmse, label=label, index=index)

    print("Train RMSE: %s " % train_rmse)
    print("Train RMSE Mean: %.2f " % statistics.mean(train_rmse))
    print("Test RMSE: %s " % test_rmse)
    print("Test RMSE Mean: %.2f " % statistics.mean(test_rmse))
    print("SSE: %s" % train_sse)
    print("Average SSE: %.2f " % statistics.mean(train_sse))
    print("Standard Deviation of SSE across folds: %.2f " % statistics.stdev(train_sse))


def run_grad_with_housing():
    print_dataset_name(name="Housing")
    run_gradient_descent(data=get_data_without_normalize("housing"), learning_rate=0.0004, num_iter=1000,
                         tolerence=0.005,
                         label="Housing")


def run_grad_with_yacht():
    print_dataset_name("Yacht")
    run_gradient_descent(data=get_data_without_normalize("yachtData"), learning_rate=0.001, num_iter=1000,
                         tolerence=0.001,
                         label="Yacht")


def run_grad_with_concrete():
    print_dataset_name("Concrete")
    run_gradient_descent(data=get_data_without_normalize("concreteData"), learning_rate=0.0007, tolerence=0.0001,
                         num_iter=1000,
                         label="Concrete")


if __name__ == '__main__':
    # Uncomment to display all columns
    # pd.set_option('display.max_rows', 500)
    # pd.set_option('display.max_columns', 500)
    # pd.set_option('display.width', 1000)
    # print(len(sys.argv))
    if len(sys.argv) == 2:
        print("Question 2. Gradient Descent")
        if sys.argv[-1] == '-h':
            print("Running Housing dataset. Graph will be saved in 'plots' folder.")
            run_grad_with_housing()

        elif sys.argv[-1] == '-y':
            print("Running Yacht dataset. Graph will be saved in 'plots' folder.")
            run_grad_with_yacht()

        elif sys.argv[-1] == '-c':
            print("Running Concrete dataset. Graph will be saved in 'plots' folder.")
            run_grad_with_concrete()

        elif sys.argv[-1] == '-a':
            print("Running all 3 dataset - Housing, Yacht, and Concrete")
            run_grad_with_housing()
            run_grad_with_yacht()
            run_grad_with_concrete()
        else:
            print("Use flags -a for all, -h for housing, -y for yacht or -c for concrete")
    else:
        print("Use flags -a for all, -h for housing, -y for yacht or -c for concrete")
