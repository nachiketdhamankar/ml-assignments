from util import create_train_test_list, calculate_rmse, calculate_sse, print_dataset_name, get_mean_stddev, \
    get_data_without_normalize, get_new_test_rmse_with_bias
import sys
import numpy as np
import statistics
import math


def gradient_descent(x, y, w, learning_rate, iterations, tolerance):
    cost_history = np.zeros(iterations)
    prev = 0.0
    w_history = []
    rmse, sse = [], []
    for it in range(iterations):
        prediction = np.dot(x, w)

        w = w - learning_rate * x.T.dot(prediction - y)
        curr_cost = calculate_rmse(w, x, y)
        if math.isclose(prev, curr_cost, abs_tol=tolerance):
            break
        w_history.append(list(w.T))
        cost_history[it] = curr_cost
        prev = curr_cost
        rmse.append(curr_cost)
        curr_sse = calculate_sse(w=w, x=x, y=y)
        sse.append(curr_sse)

    return w_history[-1], cost_history, w_history, rmse, sse


def normal_equation(x, y):
    return np.linalg.pinv(x.T.dot(x)).dot(x.T).dot(y)


def run_gradient_descent(data, n_folds=10):
    train_list, test_list = create_train_test_list(data)
    train_rmse, train_sse = [], []
    test_rmse, test_sse = [], []
    for index in range(n_folds):
        normalized__train_data, mean_per_col, stddev_per_col = get_mean_stddev(train_list[index])

        x = normalized__train_data.iloc[:, :-1].values
        y = normalized__train_data.iloc[:, -1].values
        y.shape = [y.shape[0], 1]

        x_biased = np.c_[np.ones((len(x), 1)), x]
        w = normal_equation(x=x_biased, y=y)

        train_rmse.append((calculate_rmse(w=w, x=x_biased, y=y)))
        train_sse.append((calculate_sse(w=w, x=x_biased, y=y)))

        test_rmse_val = get_new_test_rmse_with_bias(w=w, data=test_list[index], mean_list=mean_per_col,
                                                    stddev_list=stddev_per_col)

        test_rmse.append(test_rmse_val)

    print("Train RMSE: %s " % train_rmse)
    print("Train RMSE Mean: %.2f " % statistics.mean(train_rmse))
    print("Test RMSE: %s " % test_rmse)
    print("Test RMSE Mean: %.2f " % statistics.mean(test_rmse))
    print("SSE: %s" % train_sse)
    print("SSE Mean: %.2f " % statistics.mean(train_sse))
    print("Standard Deviation of SSE: %.2f " % statistics.stdev(train_sse))


def run_grad_with_housing():
    print_dataset_name(name="Housing")
    run_gradient_descent(data=get_data_without_normalize("housing"), n_folds=10)


def run_grad_with_yacht():
    print_dataset_name("Yacht")
    run_gradient_descent(data=get_data_without_normalize("yachtData"), n_folds=10)


def run_grad_with_concrete():
    print_dataset_name("Concrete")
    run_gradient_descent(data=get_data_without_normalize("concreteData"), n_folds=10)


if __name__ == '__main__':
    # Uncomment to display all columns
    # pd.set_option('display.max_rows', 500)
    # pd.set_option('display.max_columns', 500)
    # pd.set_option('display.width', 1000)

    # run_grad_with_housing()
    # run_grad_with_concrete()
    # run_grad_with_yacht()

    if len(sys.argv) == 2:
        print("Question 3. Normal Equations")
        if sys.argv[-1] == '-h':
            print("Running Housing dataset.")
            run_grad_with_housing()

        elif sys.argv[-1] == '-y':
            print("Running Yacht dataset.")
            run_grad_with_yacht()

        elif sys.argv[-1] == '-c':
            print("Running Concrete dataset.")
            run_grad_with_concrete()

        elif sys.argv[-1] == '-a':
            print("Running all 3 dataset - Housing, Yacht, and Concrete")
            run_grad_with_housing()
            run_grad_with_yacht()
            run_grad_with_concrete()
        else:
            print("Use flags -a for all, -h for housing, -y for yacht or -c for concrete")
    else:
        print("Use flags -a for all, -h for housing, -y for yacht or -c for concrete")
