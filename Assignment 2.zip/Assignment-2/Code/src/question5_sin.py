from util import calculate_sse, calculate_rmse, get_data_without_normalize, add_power, normalize_test_data
import matplotlib.pyplot as plt
import numpy as np


def get_test_rmse_sse(w, data):
    test_data = data
    actual = test_data[:, -1]
    actual.shape = [actual.shape[0], 1]
    test = test_data[:, :-1]
    test_biased = np.c_[np.ones((len(test), 1)), test]
    w.shape = [w.shape[0], 1]
    rmse = calculate_rmse(w=w, x=test_biased, y=actual)
    sse = calculate_sse(w=w, x=test_biased, y=actual)
    return rmse, sse


def normal_equation(x, y):
    return np.linalg.pinv(x.T.dot(x)).dot(x.T).dot(y)


def run_gradient_descent(train_data, validation_data, power):
    x = train_data.iloc[:, :-1].values
    y = train_data.iloc[:, -1]

    # TODO See if you have to change the shape
    # y.shape = [y.shape[0], 1]
    # print(y.shape)

    x_biased = np.c_[np.ones((len(x), 1)), x]

    w = normal_equation(x=x_biased, y=y)

    train_rmse = (calculate_rmse(w=w, x=x_biased, y=y))
    train_sse = (calculate_sse(w=w, x=x_biased, y=y))
    print("**************************")
    print("Polynomial: %s" % power)
    print("Train RMSE: %s" % train_rmse)
    print("Train SSE: %s " % train_sse)
    validation_rmse_val, validation_sse_val = get_test_rmse_sse(w=w, data=validation_data.values)
    print("Validation RMSE: %s" % validation_rmse_val)
    print("Validation SSE: %s" % validation_sse_val)
    return train_sse, validation_sse_val


def plot_graph(train_sse, validation_sse):
    train_sse_num = np.array(train_sse)
    validate_sse_num = np.array(validation_sse)
    n_val = np.array(range(1, 16))
    fig, ax = plt.subplots()
    ax.plot(n_val, train_sse_num, 'b.-', label='Train SSE')
    ax.plot(n_val, validate_sse_num, 'r.-', label='Validation SSE')
    ax.set(xlabel='Polynomial: N', ylabel='SSE',
           title='Question 5.1 - Sinusoid - SSE v/s Polynomial N')
    plt.legend(loc=0, shadow=True)
    plt.savefig('../plots/question_5_sin_data')
    plt.show()


def main():
    train_sse, validation_sse = [], []
    for n_value in range(1, 16):
        train_data = get_data_without_normalize("sinData_Train")
        validation_data = get_data_without_normalize("sinData_Validation")
        train_sin_data = train_data
        validate_sin_data = validation_data
        new_data_train = add_power(power=n_value, data=train_sin_data)
        new_data_test = add_power(power=n_value, data=validate_sin_data)
        train_sse_val, validation_sse_val = run_gradient_descent(new_data_train, new_data_test, power=n_value)
        train_sse.append(train_sse_val)
        validation_sse.append(validation_sse_val)
    plot_graph(train_sse, validation_sse)


if __name__ == '__main__':
    main()
