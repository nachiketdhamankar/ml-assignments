from util import create_train_test_list, calculate_sse, calculate_rmse, get_normalized_data, get_mean_stddev, \
    get_new_test_rmse_with_bias
import numpy as np
import statistics
import matplotlib.pyplot as plt


def add_power_new(power, data):
    original_len = len(data.columns)
    if power < 2:
        return data
    for i in range(2, power + 1, 1):
        for j in range(original_len - 1):
            values_with_power = data[j] ** i
            data.insert(loc=len(data.columns) - 1, column=str(j) + '^' + str(i),
                        value=values_with_power)
    return data


def normal_equation(x, y):
    return np.linalg.pinv(x.T.dot(x)).dot(x.T).dot(y)


def main():
    n_folds = 10

    final_mean_rmse_train, final_mean_test_rmse = [], []

    for n_value in range(1, 8):
        train_data_original = get_normalized_data("yachtData")
        train_data_sub = train_data_original
        print("\n***************")
        print("N: %s" % n_value)
        new_data = add_power_new(power=n_value, data=train_data_sub)
        train_list, test_list = create_train_test_list(new_data)
        train_rmse, train_sse = [], []
        test_rmse = []
        for index in range(n_folds):
            # x = train_list[index].iloc[:, :-1].values
            # y = train_list[index].iloc[:, -1].values
            # y.shape = [y.shape[0], 1]
            normalized__train_data, mean_per_col, stddev_per_col = get_mean_stddev(train_list[index])

            x = normalized__train_data.iloc[:, :-1].values
            y = normalized__train_data.iloc[:, -1].values
            y.shape = [y.shape[0], 1]

            x_biased = np.c_[np.ones((len(x), 1)), x]
            w = normal_equation(x=x_biased, y=y)
            train_rmse.append((calculate_rmse(w=w, x=x_biased, y=y)))
            train_sse.append((calculate_sse(w=w, x=x_biased, y=y)))

            test_rmse_val = get_new_test_rmse_with_bias(w=w, data=test_list[index], mean_list=mean_per_col,
                                                        stddev_list=stddev_per_col)
            test_rmse.append(test_rmse_val)

        print("Train RMSE: %s " % train_rmse)
        print("Train RMSE Mean: %f " % statistics.mean(train_rmse))
        print("Test RMSE: %s " % test_rmse)
        print("Test RMSE Mean: %f " % statistics.mean(test_rmse))
        print("SSE: %s" % train_sse)
        print("SSE Mean: %f " % statistics.mean(train_sse))
        print("Standard Deviation of SSE: %f " % statistics.stdev(train_sse))
        final_mean_rmse_train.append(statistics.mean(train_rmse))
        final_mean_test_rmse.append(statistics.mean(test_rmse))

    plot_graph(final_mean_rmse_train, final_mean_test_rmse)


def plot_graph(train_sse, validation_sse):
    train_sse_num = np.array(train_sse)
    validate_sse_num = np.array(validation_sse)
    n_val = np.array(range(1, 8))
    fig, ax = plt.subplots()
    ax.plot(n_val, train_sse_num, 'b.-', label='Train RMSE')
    ax.plot(n_val, validate_sse_num, 'r.-', label='Validation RMSE')
    ax.set(xlabel='Polynomial: N', ylabel='RMSE',
           title='Question 5.1.b - Yacht - RMSE v/s Polynomial N')
    plt.legend(loc=0, shadow=True)
    plt.savefig('../plots/question_5_yacht.png')
    plt.show()


if __name__ == '__main__':
    # Uncomment the following lines to print all columns
    # pd.set_option('display.max_rows', 500)
    # pd.set_option('display.max_columns', 500)
    # pd.set_option('display.width', 1000)
    main()
