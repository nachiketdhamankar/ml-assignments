import numpy as np
from util import create_train_test_list, calculate_rmse, add_power, get_data_without_normalize
import statistics
import matplotlib.pyplot as plt
import sys


def get_centered_data(data):
    return data.sub(data.mean())


def normal_equation(x, y, lam):
    return np.linalg.pinv(x.T.dot(x) + lam * np.identity(x.shape[1])).dot(x.T).dot(y)


def get_mean(data):
    mean_list = []
    for col in data.columns:
        new_col = str(col) + 'z_norm'
        col_mean = data[col].mean()
        mean_list.append(col_mean)
        data[new_col] = data[col] - col_mean
        data.drop(columns=[col], inplace=True)
    data.columns = range(data.shape[1])

    return data, mean_list


def center_data(data, mean_list):
    index = 0
    for col in data.columns:
        new_col = str(col) + 'z_norm'
        col_mean = mean_list[index]
        index += 1
        data[new_col] = data[col] - col_mean
        data.drop(columns=[col], inplace=True)
    data.columns = range(data.shape[1])
    return data.values


def get_new_test_rmse_without_bias(w, data, mean_list):
    test_data = center_data(data, mean_list)
    actual = test_data[:, -1]
    actual.shape = [actual.shape[0], 1]
    test = test_data[:, :-1]
    w.shape = [w.shape[0], 1]
    rmse = calculate_rmse(w=w, x=test, y=actual)
    return rmse


def run_algorithm(data, lambd, n_folds=10):
    # centered_data = get_centered_data(data)
    centered_data = data
    train_list, test_list = create_train_test_list(data=centered_data)
    train_rmse, test_rmse = [], []
    for index in range(n_folds):
        normalized__train_data, mean_per_col = get_mean(train_list[index])
        x = normalized__train_data.iloc[:, :-1].values
        y = normalized__train_data.iloc[:, -1].values
        y.shape = [y.shape[0], 1]

        w = normal_equation(x, y, lambd)

        test_val = get_new_test_rmse_without_bias(w=w, data=test_list[index], mean_list=mean_per_col)
        test_rmse.append(test_val)
        train_rmse.append(calculate_rmse(w=w, x=x, y=y))

    return statistics.mean(train_rmse), statistics.mean(test_rmse)


def plot_graph(train_rmse, test_rmse, p):
    train_data = np.array(train_rmse)
    test_data = np.array(test_rmse)
    lambd = np.arange(0, 10.1, 0.2)

    fig, ax = plt.subplots()
    ax.plot(lambd, train_data, 'b.-', label='Train RMSE')
    ax.plot(lambd, test_data, 'r.-', label='Test RMSE')

    question_no = 1 if p == 5 else 2
    ax.set(xlabel='Lambda', ylabel='RMSE',
           title='Question 7.%s Lambda v/s RMSE - (x^%s)' % (question_no, p - 1))
    plt.legend(loc=0, shadow=True)
    plt.savefig('../plots/question_7_yacht_p' + str(p - 1) + '.png')
    plt.show()


def main(p):
    sin_data = get_data_without_normalize("sinData_Train")

    # Modify the next line to test for fewer number of rows
    mod_sin_data = sin_data

    pow_sin_data = add_power(p, mod_sin_data)
    train_rmse_at_n, test_rmse_at_n = [], []
    for lambd in np.arange(0, 10.1, 0.2):
        train_rmse_at_n_val, test_rmse_at_n_val = run_algorithm(data=pow_sin_data, lambd=lambd, n_folds=10)
        train_rmse_at_n.append(train_rmse_at_n_val)
        test_rmse_at_n.append(test_rmse_at_n_val)
    plot_graph(train_rmse_at_n, test_rmse_at_n, p)


if __name__ == '__main__':

    if len(sys.argv) == 3:
        print("Question 7. Ridge Regression")
        if sys.argv[-2] == '-p':
            if sys.argv[-1] == '5' or sys.argv[-1] == '9':
                # print((int(sys.argv[-1])))
                main(int(sys.argv[-1]) + 1)
            else:
                print("Choose value of p to be either 5 or 9.")
        else:
            print("Usage: \npython question7.py -p 5 (for p=5) and \npython question7.py -p 9 (for p=9)")
    else:
        print("Usage: \npython question7.py -p 5 (for p=5) and \npython question7.py -p 9 (for p=9)")
