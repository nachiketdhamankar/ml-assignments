import pandas as pd
import operator
import pickle
import csv


def get_sorted_dict_of_word_id_count(data):
    word_count_dict = {}
    for index, row in data.iterrows():
        if row['wordIdx'] in word_count_dict.keys():
            word_count_dict[row['wordIdx']] += row['count']
        else:
            word_count_dict[row['wordIdx']] = 0 + row['count']
    return word_count_dict


def write_top_n_items_of_dict(dict_data, n, save_dict=False, write_to_file=False):
    count = 1
    word_count_for_n = {}
    for key, values in dict_data.items():
        if count > n:
            break
        else:
            word_count_for_n[key] = values
            count += 1

    if save_dict:
        with open('../cache/saved_dicts/' + str(n) + '.pickle', 'wb') as handle:
            pickle.dump(word_count_for_n, handle, protocol=pickle.HIGHEST_PROTOCOL)

    if write_to_file:
        file = csv.writer(open("../word_frequencies/" + str(n) + ".csv", "w", newline=""))
        for key, val in word_count_for_n.items():
            file.writerow([key, val])


def read_data():
    file_name = "../dataset/20news-bydate/matlab/train.data"
    return pd.read_csv(file_name, delim_whitespace=True, header=None, names=['docIdx', 'wordIdx', 'count'])


def main():
    """
    The main function to create the word frequencies for the dataset.
    """
    data = read_data()

    word_count_dict = get_sorted_dict_of_word_id_count(data=data)

    sorted_word_count_dict = dict(sorted(word_count_dict.items(), key=operator.itemgetter(1), reverse=True))

    vocab_sizes = [100, 500, 1000, 2500, 5000, 7500, 10000, 12500, 25000, 50000, len(sorted_word_count_dict)]
    for size in vocab_sizes:
        write_top_n_items_of_dict(sorted_word_count_dict, size, save_dict=True, write_to_file=True)


if __name__ == '__main__':
    # Uncomment to display all columns
    # pd.set_option('display.max_rows', 500)
    # pd.set_option('display.max_columns', 500)
    # pd.set_option('display.width', 1000)
    main()
