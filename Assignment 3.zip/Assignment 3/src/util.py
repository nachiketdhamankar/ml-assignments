import pandas as pd
import numpy as np


def get_data(dataset_name):
    file_name = "../dataset/" + dataset_name + ".csv"
    data = pd.read_csv(file_name, header=None)
    return data


def sigmoid(z):
    return 1 / (1 + np.exp(-z))


def get_normalized_data(dataset_name):
    file_name = "../dataset/" + dataset_name + ".csv"
    data = pd.read_csv(file_name, header=False)
    return z_score_normalize(data)


def get_mean_stddev(data):
    mean_list, stddev_list = [], []
    for col in data.columns:
        new_col = str(col) + 'z_norm'
        col_mean = data[col].mean()
        col_stddev = data[col].std(ddof=0)
        mean_list.append(col_mean)
        stddev_list.append(col_stddev)
        data[new_col] = (data[col] - col_mean) / col_stddev
        data[new_col].fillna(0, inplace=True)
        data.drop(columns=[col], inplace=True)
    data.columns = range(data.shape[1])

    return data, mean_list, stddev_list


def normalize_test_data(data, mean_list, stddev_list):
    index = 0
    for col in data.columns:
        new_col = str(col) + 'z_norm'
        col_mean = mean_list[index]
        col_stddev = stddev_list[index]
        index += 1
        data[new_col] = (data[col] - col_mean) / col_stddev
        data.drop(columns=[col], inplace=True)
    data.columns = range(data.shape[1])
    return data.values


def create_train_test_list(data):
    df = data.sample(frac=1).reset_index(drop=True)
    train_data, test_data = [], []
    n_folds = 10
    dfList = np.array_split(df, n_folds)
    for x in range(n_folds):
        trainList = []
        for y in range(n_folds):
            if y == x:
                testdf = dfList[y]
            else:
                trainList.append(dfList[y])
        traindf = pd.concat(trainList)
        train_data.append(traindf)
        test_data.append(testdf)
    return train_data, test_data


def z_score_normalize(data):
    for col in data.columns:
        new_col = str(col) + 'z_norm'
        data[new_col] = (data[col] - data[col].mean()) / data[col].std(ddof=0)
        data.drop(columns=[col], inplace=True)
    data.columns = range(data.shape[1])
    return data
