import pandas as pd
import numpy as np
import pickle


def get_class_prior():
    train_label = open('../dataset/20news-bydate/matlab/train.label')

    pi = {}

    for i in range(1, 21):
        pi[i] = 0

    lines = train_label.readlines()

    total = len(lines)

    for line in lines:
        val = int(line.split()[0])
        pi[val] += 1

    documents_per_class = pd.DataFrame.from_dict(pi, orient='index', dtype=float)

    # Divide the count of each class by total documents
    for key in pi:
        pi[key] /= total

    probability_of_documents_per_class = pd.DataFrame.from_dict(pi, orient='index', dtype=float)

    return documents_per_class, probability_of_documents_per_class


def create_single_dataframe():
    # Training data
    train_data = open('../dataset/20news-bydate/matlab/train.data')
    df = pd.read_csv(train_data, delimiter=' ', names=['docIdx', 'wordIdx', 'count'])

    # Training label
    label = []
    train_label = open('../dataset/20news-bydate/matlab/train.label')
    lines = train_label.readlines()
    for line in lines:
        label.append(int(line.split()[0]))

    # Increase label length to match docIdx
    docIdx = df['docIdx'].values
    i = 0
    new_label = []
    for index in range(len(docIdx) - 1):
        new_label.append(label[i])
        if docIdx[index] != docIdx[index + 1]:
            i += 1
    new_label.append(label[i])  # for-loop ignores last value

    # Add label column
    df['classIdx'] = new_label

    return df


def create_theta_matrix(class_prior, documents_per_class, from_cache=False):
    if from_cache:
        theta_matrix = np.genfromtxt('../cache/question2/bernoulli/theta_matrix.csv', delimiter=',')
        return theta_matrix
    else:
        vocabulary = 61188
        number_of_classes = class_prior.size
        # Make theta matrix 53975 x 20 (Since there are only 53975 unique words in the training set)
        # => (61188-53975) words appear uniquely in the test
        theta_matrix = np.zeros([vocabulary, number_of_classes])

        word_occurrences = np.row_stack([np.arange(vocabulary) + 1, np.zeros(vocabulary)])

        data = create_single_dataframe()
        for index, row in data.iterrows():
            theta_matrix[row.loc['wordIdx'] - 1][row.loc['classIdx'] - 1] += 1
            word_occurrences[1][row.loc['wordIdx'] - 1] += row.loc['count']

        theta_matrix = np.transpose(theta_matrix)

        theta_matrix = np.row_stack([word_occurrences, theta_matrix])
        word_frequencies = theta_matrix[1, :].argsort()
        theta_matrix_by_freq = theta_matrix[:, word_frequencies]
        theta_matrix = np.flip(theta_matrix_by_freq, 1)

        theta_matrix = theta_matrix[2:, :]

        for i in range(number_of_classes):
            theta_matrix[i] = (theta_matrix[i] + 1) / (documents_per_class.values[i] + 2)

        np.savetxt('../cache/question2/bernoulli/theta_matrix.csv', theta_matrix, delimiter=',')
        return theta_matrix


def get_n_documents(n):
    try:
        n_documents = pickle.load(open('../cache/saved_dicts/' + str(n) + '.pickle', 'rb'))
        new_dict = dict()
        i = 0
        for key in n_documents.keys():
            if i == n:
                break
            new_dict[key] = i
            i += 1
        return new_dict
    except Exception as e:
        raise Exception(
            "Word Frequencies not found. Please run Question 2.1 to create the word frequencies first. "
            "Also, ensure you have the cache folder in it's appropriate place (as explained in the README.txt")


def predict(x, theta_matrix, class_prior):
    class_prior = np.log(class_prior)
    neg_theta_matrix = 1 - theta_matrix

    theta_matrix = np.log(theta_matrix)
    neg_theta_matrix = np.log(neg_theta_matrix)

    max_prob = float("-inf")
    doc_id = 0
    for i in range(theta_matrix.shape[0]):
        prob_of_word_in_doc = 0
        for j in range(theta_matrix.shape[1]):
            prob_of_word_in_doc += theta_matrix[i][j] if x[j] == 1 else neg_theta_matrix[i][j]
        curr_prob = prob_of_word_in_doc + class_prior[i]
        if curr_prob > max_prob:
            max_prob = curr_prob
            doc_id = i
    return doc_id + 1


def create_test_matrix(size):
    n_documents = get_n_documents(n=size)

    test_data = pd.read_csv('../dataset/20news-bydate/matlab/test.data', delimiter=' ',
                            names=['docIdx', 'wordIdx', 'count'])

    num_test_documents = 7505
    num_words = len(n_documents)
    test_matrix = np.zeros([num_test_documents, num_words], dtype=object)
    for index, row in test_data.iterrows():
        if row.loc['wordIdx'] in n_documents:
            test_matrix[row.loc['docIdx'] - 1][n_documents[row.loc['wordIdx']]] = 1
    return test_matrix


def get_predicted_values(test_matrix, theta_matrix, documents_per_class):
    predicted_values = np.zeros(test_matrix.shape[0])
    for index in range(test_matrix.shape[0]):
        predicted_values[index] = predict(test_matrix[index], theta_matrix, documents_per_class)
    return predicted_values


if __name__ == '__main__':
    # Uncomment to display all columns
    # pd.set_option('display.max_rows', 500)
    # pd.set_option('display.max_columns', 500)
    # pd.set_option('display.width', 1000)

    documents_per_class, class_prior = get_class_prior()  # Fetch the probability of documents per class

    # Set from_cache to false if you do not want to use the cache files (Will take a lot of time to run. Be patient.
    # Really Really patient.)
    theta_matrix = create_theta_matrix(class_prior=class_prior, documents_per_class=documents_per_class,
                                       from_cache=True)

    # Change the size of the vocabulary list to the one you want
    # for size in [100,500, 1000, 5000, 7500, 10000, 12500, 25000, 50000, 53975]:
    for size in [100]:
        updated_theta_matrix = theta_matrix.view()[:, :size]
        test_matrix = create_test_matrix(size=size)
        predicted_values = get_predicted_values(test_matrix, updated_theta_matrix, class_prior.values)
        np.savetxt('../cache/question2_predicted/' + str(size) + '_predicted_values_bernoulli.csv', predicted_values,
                   fmt='%d', delimiter=',')
        print('Done: ' + str(size))
    print('All vocabulary sizes for bernoulli completed. Congrats. You have a lot of patience.')
