import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


def calculate_accuracy(predicted_values, actual_values):
    predicted_values = predicted_values
    correct_prediction = predicted_values == actual_values
    accuracy = correct_prediction.sum() / actual_values.size
    return accuracy[0]


def get_metrics(model_name):
    accuracy = []
    final_recall = {}
    final_precision = {}
    actual_values = pd.read_csv('../dataset/20news-bydate/matlab/test.label', header=None)

    # Change parameters here
    # for size in [100,500, 1000, 5000, 7500, 10000, 12500, 25000, 50000, 53975]:
    for size in [100]:
        predicted_values = pd.read_csv(
            '../cache/question2_predicted/' + str(size) + '_predicted_values_' + model_name + '.csv',
            header=None)
        accuracy.append(calculate_accuracy(predicted_values=predicted_values, actual_values=actual_values))
        recall = []
        precision = []
        for class_id in range(1, 21):
            curr_recall, curr_precision = get_recall_precision(actual=actual_values, predicted=predicted_values,
                                                               class_id=class_id)
            recall.append(curr_recall.tolist())
            precision.append(curr_precision.tolist())
        final_recall[size] = recall
        final_precision[size] = precision
    return accuracy, final_recall, final_precision


def get_recall_precision(actual, predicted, class_id):
    true_positive = ((actual == class_id) & (predicted == class_id)).sum()
    total_actual_label = (actual == class_id).sum()
    total_predicted_label = (predicted == class_id).sum()
    recall = true_positive / total_actual_label
    precision = true_positive / total_predicted_label
    return recall[0], precision[0]


def calculate_parameters():
    bernoulli_accuracy, bernoulli_recall, bernoulli_precision = get_metrics(model_name='bernoulli')
    multi_accuracy, multi_recall, multi_precision = get_metrics(model_name='multi')
    plot_accuracy(bernoulli_accuracy=bernoulli_accuracy, multi_accuracy=multi_accuracy)
    plot_recall_precision(bernoulli_precision=bernoulli_precision, bernoulli_recall=bernoulli_recall,
                          multi_precision=multi_precision, multi_recall=multi_recall)


def plot_accuracy(bernoulli_accuracy, multi_accuracy):
    bernoulli_accuracy = [accuracy * 100 for accuracy in bernoulli_accuracy]
    multi_accuracy = [accuracy * 100 for accuracy in multi_accuracy]

    working_sizes = [100]
    index = np.arange(min(len(bernoulli_accuracy), len(multi_accuracy)))
    width = 0.30

    fig, ax = plt.subplots()
    multi_index = index + width / 2
    bernoulli_index = index - width / 2

    ax.bar(multi_index, multi_accuracy, width, label='Multinomial')
    ax.bar(bernoulli_index, bernoulli_accuracy, width, label='Multivariate Bernoulli')

    ax.set_title('Accuracy v/s Vocabulary Size')
    ax.set_xlabel('Vocabulary Size')
    ax.set_xticks(index)
    ax.set_xticklabels(working_sizes[:min(len(bernoulli_accuracy), len(multi_accuracy))])
    ax.set_ylabel('Accuracy (%)')
    ax.legend(loc='best')
    plt.savefig('../plots/question2/Accuracy.png')
    plt.show()


def plot_r_p(label, data1, data2, vocab_size):
    data1 = [sub_data * 100 for sub_data in data1]
    data2 = [sub_data * 100 for sub_data in data2]

    class_size = np.arange(1, 21)
    width = 0.35
    plt.bar(class_size, data1, width=width, label='Multivariate Bernoulli')
    plt.bar(class_size + width, data2, width=width, label='Multinomial')
    plt.ylabel(label + ' (%)', fontsize=9)
    plt.xlabel('Class', fontsize=9)
    plt.xticks(class_size, label=class_size, fontsize=9, rotation=30)
    plt.title(label + '- Vocabulary Size: ' + str(vocab_size))
    plt.legend(loc='best')
    plt.savefig('../plots/question2/recall_precision/' + str(vocab_size) + '/' + label + '_' + str(vocab_size) + '.png')
    plt.show()
    plt.close()


def plot_recall_precision(bernoulli_recall, bernoulli_precision, multi_recall, multi_precision):
    for vocab_size in multi_recall.keys():
        plot_r_p('Recall', bernoulli_recall[vocab_size], multi_recall[vocab_size], vocab_size)
        plot_r_p('Precision', bernoulli_precision[vocab_size], multi_precision[vocab_size], vocab_size)


if __name__ == '__main__':
    calculate_parameters()
