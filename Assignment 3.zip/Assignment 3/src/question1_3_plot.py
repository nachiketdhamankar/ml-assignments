from util import get_data, create_train_test_list, get_mean_stddev, normalize_test_data
import numpy as np
import statistics
from sklearn.metrics import accuracy_score
import math
import matplotlib.pyplot as plt


def sigmoid(z):
    return 1 / (1 + np.exp(-z))


def loss(w, x, y):
    sig = sigmoid(x.dot(w))
    cost = -((y * np.log(sig) + (1 - y) * np.log(1 - sig)).mean())
    return cost


def gradient_descent(x, y, w, learning_rate, iterations, tolerance):
    prev = 0.0
    w_history = []
    loss_list = []
    for it in range(iterations):
        prediction = x.dot(w)
        w = w - learning_rate * (x.T.dot(prediction - y) / y.size)
        curr_loss = loss(w, x, y)
        if math.isclose(prev, curr_loss, abs_tol=tolerance):
            break
        w_history.append(list(w.T))
        prev = curr_loss
        loss_list.append(curr_loss)
    return w, w_history, loss_list


def regression(data, label, learning_rate=0.0001, num_iter=10000, tolerance=0.001, should_plot=True,
               should_save=False):
    n_folds = 10
    train_list, test_list = create_train_test_list(data)

    train_loss, train_sse = [], []
    test_accuracy_list, train_accuracy_list = [], []
    total_loss_list = []
    for index in range(n_folds):
        train_actual = train_list[index].iloc[:, -1].values
        train_actual.shape = [train_actual.shape[0], 1]

        normalized__train_data, mean_per_col, stddev_per_col = get_mean_stddev(train_list[index])

        x = normalized__train_data.iloc[:, :-1].values
        y = train_actual
        y.shape = [y.shape[0], 1]
        x_biased = np.c_[np.ones((len(x), 1)), x]

        w = np.zeros((x_biased.shape[1], 1))

        w, w_history, loss_list = gradient_descent(x_biased, y, w, learning_rate, num_iter, tolerance)
        curr_loss = loss_list

        train_pred = (sigmoid(x_biased.dot(w)) >= 0.5).astype('int')

        curr_train_acc_score = accuracy_score(train_actual, train_pred, normalize=False)
        curr_train_acc = curr_train_acc_score / train_pred.shape[0]
        curr_test_acc = get_test_accuracy(w=w, data=test_list[index], mean_list=mean_per_col,
                                          stddev_list=stddev_per_col)

        train_accuracy_list.append(curr_train_acc)
        train_loss.append(statistics.mean(curr_loss))
        test_accuracy_list.append(curr_test_acc)
        total_loss_list.append(loss_list)

        if should_plot and index == 0:
            plot_graph(loss_list=loss_list, label=label, should_save=should_save, index=index)

    print("Train Accuracy: %s " % train_accuracy_list)
    print("Train Accuracy Mean: %.5f " % statistics.mean(train_accuracy_list))
    print("Standard Deviation of Train Accuracy across folds: %f " % statistics.stdev(train_accuracy_list))
    print("Test Accuracy: %s " % test_accuracy_list)
    print("Test Accuracy Mean: %.5f " % statistics.mean(test_accuracy_list))
    print("Standard Deviation of Test Accuracy across folds: %.5f " % statistics.stdev(test_accuracy_list))


def plot_graph(loss_list, label, should_save, index=1):
    y_plot_data = np.array(loss_list)
    x_plot_data = np.arange((len(loss_list)))
    fig, ax = plt.subplots()
    ax.plot(x_plot_data, y_plot_data, 'r.-')

    ax.set(xlabel='No. of Iterations', ylabel='Logistic Loss')
    plt.title(str(label) + ' - Fold: ' + str(index + 1))
    if should_save:
        plt.savefig('../plots/question1/' + str(label) + '.png')
    plt.show()


def get_test_accuracy(w, data, mean_list, stddev_list):
    actual = data.iloc[:, -1].values
    actual.shape = [actual.shape[0], 1]
    test_data = normalize_test_data(data=data, mean_list=mean_list, stddev_list=stddev_list)
    test = test_data[:, :-1]
    test_biased = np.c_[np.ones((len(test), 1)), test]
    predictions = sigmoid(test_biased.dot(w))
    new_pred = (predictions >= 0.5).astype('int')
    return np.mean(new_pred == actual)


def run_breast_cancer():
    data = get_data('breastcancer')
    regression(data, label="Question 1. Breast Cancer Dataset", learning_rate=0.0025, num_iter=1000, tolerance=0.000001,
               should_plot=True, should_save=False)


def run_spambase():
    data = get_data('spambase')
    regression(data, label="Question 1. Spambase Dataset", learning_rate=0.0005, num_iter=2500, tolerance=0.0000001,
               should_plot=True, should_save=True)


def run_diabetes():
    data = get_data('diabetes')
    regression(data, label="Question 1. Diabetes Dataset", learning_rate=0.001, num_iter=1000, tolerance=0.000004,
               should_plot=True, should_save=False)


if __name__ == '__main__':
    """
    The main function.
    To run the model for the dataset, uncomment the dataset you want to run.
    If you want to change the parameters, change them in run_{dataset_name}() function.
    Please make sure to set the options you want - should_plot and should_save
    """
    # Uncomment to display all columns
    # pd.set_option('display.max_rows', 500)
    # pd.set_option('display.max_columns', 500)
    # pd.set_option('display.width', 1000)

    # run_breast_cancer()
    # run_diabetes()
    run_spambase()
