Question 1.
1.2. Programming Task
	- To calculate mean and standard deviation of ten fold cross validation for the three datasets using logistic regression - \src\question1_3.py
	- To show the progression of the gradient descent algorithm by plotting the logistic loss for each iteration till convergence - \src\question1_3_plot.py
	
1.3. Deliverables
	1. File - \plots\question1\Summary.txt
	2. 3 Plots in the directory - \plots\question1\
	3. Explanation in file - plots\question1\question1_3_3.txt
	
1.4. The sigmoid function
	- All 3 questions answered in the file - \Written Answers\question1_4.pdf
	
Question 2.

2.4.
	1. Word Frequencies are in the folder - \word_frequencies
	2. The source code in - \src\question2_1.py
	3. Multivariate Bernouli source code in - \src\question2_bernoulli.py
	4. Multivariate event model source code in - \src\question2_multinomial.py
2.5.
	1. and 2. 
		- All the plots are present in the folder \plots\question2\
		- Plot source code is present in - \src\question2_plot.py
2.6.
	- All the questions are answered in the file - \Written Answers\question2_6.pdf



Code

- All code is in the src\ folder.
- Install pipenv
- Install the requirements using 
	``` pipenv install -r requirements.txt ```
- cd into src\ using
	``` cd src ```
- Make the necessary changes in the file (Uncomment the appropriate lines. More instructions in each of the file) and run using
	``` python {filename}.py ```

* Note
 - Make sure you do not change the file structure (or remove files from the submission). My program does not create folders if they're not present and will throw an exception.
 - The code takes a lot of time to run.
 - For question 2, each program has an order to maintain. Run question2_1.py to create the word_frequencies, then run question2_bernoulli.py and question2_multinomial.py to generate the predictions and then run question2_plot.py to generate the plots in the \plots\question2 folder
 