from operator import itemgetter
import numpy as np
import math
from util.util import sq_error_value, accuracy_calculation_reg, split, create_train_data, create_test_data
from decision_node.binary_node import BinaryNode


class HousingRegression(BinaryNode):

    def classify(self, test, tree):
        """
        Classify the given instance in that tree
        :param test: The instance to be tested
        :param tree: The tree in which that instance is to be tested
        :return: Classify the test row in that tree
        """

        if tree.col == -1:
            return tree.results
        else:
            if test[tree.col] >= tree.value:
                if isinstance(tree.left_tree, HousingRegression):
                    return self.classify(test, tree.left_tree)
                else:
                    return tree.left_tree
            else:
                if isinstance(tree.right_tree, HousingRegression):
                    return self.classify(test, tree.right_tree)
                else:
                    return tree.right_tree

    def build_tree(self, sorted_data, min_size):
        def split_function(row_to_test, feature_to_test, value):
            """
            Finds if the row data should be on the right sub tree or the left
            :param row_to_test: Row of data to test
            :param feature_to_test: The column number of the feature to test
            :param value: The threshold value of the feature
            :return: If the row is valid
            """
            return row_to_test[feature_to_test] >= value

        def partition(sorted_data, feature_to_be_split, list_split_values):
            """
            Creates a partition in a tree by checking the best split using information gain
            :param sorted_data: the sorted data which is to be parted
            :param feature_to_be_split: The column number of the feature at which a split could occur
            :param list_split_values: The list of values at the split
            :return: 2 Sub-branches: Left and Right and the best split value
            """

            true_set, false_set = [], []
            for row_test in sorted_data:
                if np.all(split_function(row_test, feature_to_be_split, list_split_values)):
                    true_set.append(row_test)
                else:
                    false_set.append(row_test)
            return true_set, false_set

        sum = 0.0
        for row in range(len(sorted_data)):
            sum = sum + sorted_data[row][-1]
        mean_value = sum / len(sorted_data)

        if len(sorted_data) == 0:
            return HousingRegression()
        current_error = sq_error_value(sorted_data, mean_value)

        best_error = math.inf
        best_sets = None
        count_of_features = len(sorted_data[0]) - 1

        for feature in range(0, count_of_features):

            for i in range(len(sorted_data)):
                true_values, false_values = partition(sorted_data, feature, sorted_data[i][feature])

                if len(true_values) == 0 or len(false_values) == 0:
                    continue
                else:
                    p1 = float(len(true_values)) / len(sorted_data)
                    p2 = float(len(false_values)) / len(sorted_data)
                    sum1 = 0.0
                    for row in range(len(true_values)):
                        sum1 = sum1 + true_values[row][-1]
                    sum2 = 0.0
                    for row in range(len(false_values)):
                        sum2 = sum2 + false_values[row][-1]
                    mean_value1 = sum1 / len(true_values)
                    mean_value2 = sum2 / len(false_values)
                    error = p1 * sq_error_value(true_values, mean_value1) + \
                            p2 * sq_error_value(false_values, mean_value2)

                    if (error < best_error and len(true_values) >= min_size and len(false_values) >= min_size):
                        best_error = error
                        best_criteria = (feature, sorted_data[i][feature])
                        best_sets = (true_values, false_values)

        # Choosing the branches of the decision tree
        if best_error < current_error:
            true_branch = self.build_tree(best_sets[0], min_size)
            false_branch = self.build_tree(best_sets[1], min_size)
            return HousingRegression(col=best_criteria[0], value=best_criteria[1],
                                     left_tree=true_branch, right_tree=false_branch)
        else:
            return HousingRegression(col=-1, results=mean_value)

    def decision_tree(self, test_data, train_data, min_size):
        """
        Builds the decision tree and then predicts the values on test data and the training data
        :param test_data: Data used for testing
        :param train_data: The data used for training
        :param min_size: The minimum number of instances in a leaf node
        :return: Predictions on test data and Predictions on train data
        """

        def decision_tree_predictions(data_for_prediction):
            """
            Classifies each row in the data and predicts its value
            :param data_for_prediction: Data used for prediction
            :return: List of predicted values
            """
            prediction_list = []
            for row in data_for_prediction:
                predicted_value = self.classify(row, tree)
                prediction_list.append(predicted_value)
            return prediction_list

        tree = self.build_tree(sorted(train_data, key=itemgetter(len(train_data[0]) - 1)), min_size)
        predictions = decision_tree_predictions(test_data)
        predictions_train = decision_tree_predictions(train_data)
        return predictions, predictions_train

    def start_model(self, dataset, n_folds, min_size, is_regression=False):
        """
        Run the decision tree algorithm
        :param dataset: Given dataset
        :param n_folds: The number of folds given
        :param min_size: Minimum instances at each leaf node
        :param is_regression: If the tree is a regression tree
        :return: Actual, Predicted, Scores, and Training score
        """
        folds = split(dataset, n_folds)
        scores_test, scores_train = [], []
        actual_test_data_over_all_folds, predicted_test_data_over_all_folds = [], []
        index = 0
        for fold in folds:

            train_data = create_train_data(folds, index)
            index += 1

            test_data = create_test_data(fold)

            actual_train = []

            for i in range(len(train_data)):
                actual_train.append(train_data[i][-1])

            actual_test = [row[-1] for row in fold]
            actual_test_data_over_all_folds.append(actual_test)
            predicted_test, predicted_train = self.decision_tree(test_data, train_data, min_size)

            predicted_test_data_over_all_folds.append(predicted_test)
            accuracy = accuracy_calculation_reg(actual_test, predicted_test)
            scores_test.append(accuracy)
            accuracy = accuracy_calculation_reg(actual_train, predicted_train)
            scores_train.append(accuracy)
        return actual_test_data_over_all_folds, predicted_test_data_over_all_folds, scores_test, scores_train
