from operator import itemgetter
from util.util import unique_class_counts, entropy, info_gain, accuracy_calculation, mean, create_train_data, \
    create_test_data, split


class BinaryNode(object):
    def __init__(self, col=-1, value=None, results=None, left_tree=None, right_tree=None):
        """
        Creates a BinaryNode object which is integral part of Decision Tree.
        :param col: The column number of the feature
        :param value: The threshold value for a split
        :param results: The instances of results
        :param left_tree: Left sub tree
        :param right_tree: Right sub tree
        """
        self.right_tree = right_tree
        self.left_tree = left_tree
        self.col = col
        self.value = value
        self.results = results

    def classify(self, test, tree):
        """
        Classify the given instance in that tree
        :param test: The instance to be tested
        :param tree: The tree in which that instance is to be tested
        :return: Classify the test row in that tree
        """
        if tree.left_tree is None and tree.right_tree is None:
            return max(tree.results.items(), key=itemgetter(1))[0]
        else:
            if test[tree.col] >= tree.value:
                return self.classify(test, tree.left_tree)
            else:
                return self.classify(test, tree.right_tree)

    def build_tree(self, data, min_size):
        """
        Generate the decision tree for the given values.
        :param data: The dataset for which the tree is generated
        :param min_size: The minimum instances at leaf node
        :return: BinaryNode() Object to generate a new tree
        """

        def split_function(row_to_test, feature_to_test, value):
            """
            Finds if the row data should be on the right sub tree or the left
            :param row_to_test: Row of data to test
            :param feature_to_test: The column number of the feature to test
            :param value: The threshold value of the feature
            :return: If the row is valid
            """
            return row_to_test[feature_to_test] >= value

        def partition(feature_to_be_split, list_split_values):
            """
            Creates a partition in a tree by checking the best split using information gain
            :param feature_to_be_split: The column number of the feature at which a split could occur
            :param list_split_values: The list of values at the split
            :return: 2 Sub-branches: Left and Right and the best split value
            """
            best_gain = 0.0
            current_score = entropy(data)
            best_val_for_partition, best_true, best_false = None, None, None

            for value in list_split_values:
                true_partition_values, false_partition_values = [], []

                for row in data:
                    if split_function(row, feature_to_be_split, value):
                        true_partition_values.append(row)
                    else:
                        false_partition_values.append(row)

                gain = info_gain(true_partition_values, false_partition_values, current_score)
                if gain > best_gain and len(true_partition_values) >= min_size and len(
                        false_partition_values) >= min_size:
                    best_gain, best_true, best_false, best_val_for_partition = gain, true_partition_values, \
                                                                               false_partition_values, value
            return best_true, best_false, best_val_for_partition

        # Start building the tree
        if len(data) == 0:
            return BinaryNode()

        current_entropy = entropy(data)
        best_dict, split_values, count_of_features, index = {'gain': 0.0}, [], len(data[0]) - 1, 0

        for feature in range(0, count_of_features):
            actual_result = data[0][count_of_features]

            for row in range(len(data)):
                # Since all the output (result) will be same, there will be no classification criteria
                if actual_result == data[row][count_of_features]:
                    continue
                else:
                    mean_nums = mean([data[row - 1][index], data[row][index]])
                    split_values.append(mean_nums)
                    actual_result = data[row][count_of_features]
            index += 1
            true_values, false_values, best_value = partition(feature, split_values)
            split_values = []

            if true_values is None or false_values is None:
                continue
            else:
                gain = info_gain(true_values, false_values, current_entropy)
                if gain > best_dict['gain'] and len(true_values) >= min_size and len(false_values) >= min_size:
                    best_dict = dict(gain=gain, feature=feature, feature_value=best_value,
                                     sets=(true_values, false_values))

        if best_dict['gain'] > 0:
            true_branch = self.build_tree(best_dict['sets'][0], min_size)
            false_branch = self.build_tree(best_dict['sets'][1], min_size)

            return BinaryNode(col=int(best_dict['feature']), value=best_dict['feature_value'],
                              results=unique_class_counts(data),
                              left_tree=true_branch, right_tree=false_branch)
        else:

            # No gain or eta value crossed, return leaf node
            return BinaryNode(col=-1, results=unique_class_counts(data))

    def decision_tree(self, test_data, train_data, min_size):
        """
        Builds the decision tree and then predicts the values on test data and the training data
        :param test_data: Data used for testing
        :param train_data: The data used for training
        :param min_size: The minimum number of instances in a leaf node
        :return: Predictions on test data and Predictions on train data
        """

        def decision_tree_predictions(data_for_prediction):
            """
            Classifies each row in the data and predicts its value
            :param data_for_prediction: Data used for prediction
            :return: List of predicted values
            """
            prediction_list = []
            for row in data_for_prediction:
                predicted_value = self.classify(row, tree)
                prediction_list.append(predicted_value)
            return prediction_list

        tree = self.build_tree(sorted(train_data, key=itemgetter(len(train_data[0]) - 1)), min_size)
        predictions_test = decision_tree_predictions(test_data)
        predictions_train = decision_tree_predictions(train_data)
        return predictions_test, predictions_train

    def start_model(self, dataset, n_folds, min_size, is_regression=False):
        """
        Run the decision tree algorithm
        :param dataset: Given dataset
        :param n_folds: The number of folds given
        :param min_size: Minimum instances at each leaf node
        :param is_regression: If the tree is a regression tree
        :return: Actual, Predicted, Scores, and Training score
        """

        folds = split(dataset, n_folds)
        scores_test, scores_train = [], []
        actual_test_data_over_all_folds, predicted_test_data_over_all_folds = [], []
        index = 0

        for fold in folds:
            train_data = create_train_data(folds, index)
            index += 1

            test_data = create_test_data(fold)

            actual_train = []

            for i in range(len(train_data)):
                actual_train.append(train_data[i][-1])

            actual_test = [row[-1] for row in fold]
            actual_test_data_over_all_folds.append(actual_test)

            predicted_test, predicted_train = self.decision_tree(test_data=test_data,
                                                                 train_data=train_data, min_size=min_size)
            predicted_test_data_over_all_folds.append(predicted_test)

            accuracy = accuracy_calculation(actual_test, predicted_test)
            scores_test.append(accuracy)

            accuracy = accuracy_calculation(actual_train, predicted_train)
            scores_train.append(accuracy)
        return actual_test_data_over_all_folds, predicted_test_data_over_all_folds, scores_test, scores_train
