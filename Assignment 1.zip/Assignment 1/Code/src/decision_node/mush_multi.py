import numpy as np
from operator import itemgetter
from util.util import unique_class_counts, entropy, info_gain_iterative
from decision_node.binary_node import BinaryNode


class MultiwayNode(BinaryNode):

    def classify(self, test, tree):
        """
        Classify the given instance in that tree
        :param test: The instance to be tested
        :param tree: The tree in which that instance is to be tested
        :return: Classify the test row in that tree
        """

        if tree.left_tree is None and tree.right_tree is None:
            return max(tree.results.items(), key=itemgetter(1))[0]
        else:
            for val in range(len(tree.value)):
                if test[tree.col] == tree.value[val]:
                    return self.classify(test, tree.left_tree)
                else:
                    return self.classify(test, tree.right_tree)

    def build_tree(self, data, min_size):
        """
        Generate the decision tree for the given values.
        :param data: The dataset for which the tree is generated
        :param min_size: The minimum instances at leaf node
        :return: BinaryNode() Object to generate a new tree
        """

        def partition(feature_to_be_split, feature_values):
            """
            Creates a partition in a tree by checking the best split using information gain
            :param feature_to_be_split: The column number of the feature at which a split could occur
            :param feature_values: The list of values at the split
            :return: a list with all the rows where the feature_to_be_split has the same value as that instance
            """

            set = []
            for value in feature_values:
                split_function = lambda row: row[feature_to_be_split] == value
                set.append([row for row in data if split_function(row)])
            return set

        if len(data) == 0:
            return MultiwayNode()
        current_entropy = entropy(data)
        best_gain = 0.0
        best_sets = None
        count_of_features = len(data[0]) - 1

        for feature in range(0, count_of_features):
            temp_data = np.array(data)
            attr_values = unique_class_counts(temp_data[:, feature])
            i = list(attr_values.keys())
            branches = partition(feature, i)

            flag = 0
            gain = current_entropy
            for branch in branches:
                gain = info_gain_iterative(gain, branch, data)
                if len(branch) >= min_size:
                    flag = flag + 1

            if gain > best_gain and flag == len(branches):
                best_gain = gain
                best_criteria = feature
                best_sets = []
                for set in branches:
                    best_sets.append(set)

        branch = []
        unique_keys = []
        if best_gain > 0:
            for set in best_sets:
                branch.append(self.build_tree(set, min_size))
                temp = np.array(set)
                unique_keys.extend(list(unique_class_counts(temp[:, best_criteria]).keys()))
            return MultiwayNode(col=best_criteria, value=list(unique_class_counts(unique_keys).keys()),
                                results=None, left_tree=branch[0], right_tree=branch[1])
        else:
            return MultiwayNode(col=-1, results=unique_class_counts(data))
