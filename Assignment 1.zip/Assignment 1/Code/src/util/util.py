from math import log, ceil
import pandas as pd
import numpy as np


def accuracy_calculation_reg(actual, predicted):
    score = 0.0
    for i in range(len(actual)):
        score = score + (actual[i] - predicted[i]) ** 2
    return score


def create_test_data(fold):
    test_data = []
    for row in fold:
        row_copy = list(row)
        test_data.append(row_copy)
        row_copy[-1] = None
    return test_data


def create_train_data(folds, index):
    train_data = list(folds)
    train_data = np.array(train_data)
    train_data = np.delete(train_data, index, axis=0)
    train_data = train_data.tolist()
    return sum(train_data, [])


def split(dataset, n_folds):
    np.random.shuffle(dataset)
    dataset = list(dataset)
    split_dataset = []
    sub_split = []
    entries_per_fold = int(len(dataset) // n_folds)
    for i in range(n_folds):
        for j in range(entries_per_fold):
            sub_split.append(dataset.pop(len(sub_split) - j))
        split_dataset.append(sub_split)
        sub_split = []
    return split_dataset


def unique_class_counts(train_data, col=-1):
    results = {}
    for row in train_data:
        label = row[col]
        if label not in results:
            results[label] = 0
        results[label] += 1
    return results


def entropy(data):
    def log2(x):
        return log(x) / log(2)

    possible_values = unique_class_counts(data)

    calculated_entropy = 0.0
    for value in possible_values.keys():
        prob = float(possible_values[value]) / len(data)
        calculated_entropy = calculated_entropy - prob * log2(prob)
    return calculated_entropy


def info_gain(true_values, false_values, current_score):
    p = float(len(true_values)) / len(true_values + false_values)
    return current_score - p * entropy(true_values) - (1 - p) * entropy(false_values)


def info_gain_iterative(gain, values, data):
    p = float(len(values)) / len(data)
    gain = gain - p * entropy(values)
    return gain


def is_numeric(val):
    return isinstance(val, int) or isinstance(val, float)


def accuracy_calculation(actual, predicted):
    correct_prediction = [1 for i in range(len(actual)) if actual[i] == predicted[i]]
    return (sum(correct_prediction) / float(len(actual))) * 100


def mean(list_of_nums):
    return sum(list_of_nums) / len(list_of_nums)


def best_eta(avg_score, N):
    best = []
    max_score = max(avg_score)
    j = 0
    for score in avg_score:
        if score == max_score:
            best.append(N[j])
        j += 1
    return best


def draw_confusion_matrix(dataset, node, n_folds, eta):
    size_of_data = len(dataset) + 1
    min_size = ceil(size_of_data * eta)
    actual_test, predicted_test, score, score_train = node.start_model(dataset, n_folds, min_size, False)
    print("Confusion matrix")
    actual = pd.Series(sum(actual_test, []), name='Actual')
    predicted = pd.Series(sum(predicted_test, []), name='Predicted')
    df_confusion = pd.crosstab(actual, predicted, rownames=['Actual'], colnames=['Predicted'], margins=True)
    print(df_confusion)


def average(num):
    return sum(num) / float(len(num))


def sq_error_value(train_data, mean_value):
    squared_error = 0.0
    for row in range(len(train_data)):
        squared_error = squared_error + (mean_value - train_data[row][-1]) ** 2
    return squared_error
