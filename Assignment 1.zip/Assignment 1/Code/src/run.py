import argparse
from math import ceil
import pandas as pd
from statistics import stdev
from decision_node.binary_node import BinaryNode
from decision_node.mush_multi import MultiwayNode
from util.util import best_eta, draw_confusion_matrix, average
from pathlib import Path
from decision_node.mush_bin import BinMush
from decision_node.housing_regression import HousingRegression

n_folds = 10


def run_model(model, data, N, is_regression=False):
    avg_score = []
    for i in range(len(N)):
        if not is_regression:
            _, _, score_test, score_train = model.start_model(dataset=data, n_folds=n_folds,
                                                              min_size=ceil((len(data) + 1) * N[i]),
                                                              is_regression=is_regression)
            print("\nFor eta=%s: " % (N[i]))
            avg_score.append(average(score_test))
            print("Average Test Accuracy : %s" % (average(score_test)))
            print("Standard deviation: %s " % stdev(score_test))
            print("Average Train Accuracy : %s" % (average(score_train)))
            print("Standard deviation: %s " % stdev(score_train))

        else:
            _, _, score_test, score_train = model.start_model(dataset=data, n_folds=n_folds,
                                                              min_size=ceil((len(data) + 1) * N[i]),
                                                              is_regression=is_regression)
            print("\nFor eta=%s: " % (N[i]))
            avg_score.append(average(score_test))
            print("Average Test Score : %s" % (average(score_test)))
            print("Standard deviation: %s " % stdev(score_test))
            print("Average Train Score : %s" % (average(score_train)))
            print("Standard deviation: %s " % stdev(score_train))
            
    if not is_regression:
        best_eta_val = best_eta(avg_score, N)
        print("Best values of eta: %s " % best_eta_val)
        draw_confusion_matrix(data, model, n_folds, best_eta_val[0])


def run_iris(p):
    dataset_iris = pd.read_csv(Path.joinpath(p, "dataset/iris.csv"), header=None).values
    N = [0.05, 0.10, 0.15, 0.20]
    print("*********************")
    print("Question 1.2.a - Iris")
    print("*********************")
    run_model(BinaryNode(), dataset_iris, N, is_regression=False)


def run_spam(p):
    dataset_spam = pd.read_csv(Path.joinpath(p, "dataset/spambase.csv"), header=None).values
    N = [0.05, 0.10, 0.15, 0.20, 0.25]
    print("*********************")
    print("Question 1.2.b - Spambase")
    print("*********************")

    run_model(BinaryNode(), dataset_spam, N, is_regression=False)


def run_mushroom_binary(p):
    dataset_mushroom = pd.read_csv(Path.joinpath(p, "dataset/mushroom.csv"), header=None).values
    N = [0.05, 0.10, 0.15]
    print("*********************")
    print("Question 2.1.b - Mushroom Binary")
    print("*********************")

    # run_model(BinaryNode2(), dataset_mushroom, N)
    run_model(BinMush(), dataset_mushroom, N, is_regression=False)


def run_mushroom_multiway(p):
    dataset_mushroom = pd.read_csv(Path.joinpath(p, "dataset/mushroom.csv"), header=None).values
    N = [0.05, 0.10, 0.15]
    print("*********************")
    print("Question 2.1.a - Mushroom multiway")
    print("*********************")
    run_model(MultiwayNode(), dataset_mushroom, N, is_regression=False)


def run_housing(p):
    dataset_housing = pd.read_csv(Path.joinpath(p, "dataset/housing.csv"), header=None).values
    N = [0.05, 0.10, 0.15, 0.20]
    print("*********************")
    print("Question 6. a - Housing")
    print("*********************")
    run_model(HousingRegression(), dataset_housing, N, is_regression=True)


def gather_arguments():
    parser = argparse.ArgumentParser(description='Assignment 1 for CS6140\n')
    parser.add_argument('--iris', '-i', help='Add this option for Q. 1. 1. a. Iris Dataset', action='store_true')
    parser.add_argument('--spambase', '-s', help='Add this option for Q. 1. 1. b. Spambase Dataset',
                        action='store_true')
    parser.add_argument('--mush_multi', '-mm', help='Add this option for Q. 2. 1. a. Multiway Mushroom Dataset',
                        action='store_true')

    parser.add_argument('--mush_binary', '-mb', help='Add this option for Q. 2. 1. b. Binary Mushroom Dataset',
                        action='store_true')
    parser.add_argument('--housing', '-hr', help='Add this option for Q. 6. a. Housing Dataset', action='store_true')
    parser.add_argument('--all', '-a', help='Add this option to run models for all the above datasets',
                        action='store_true')
    return parser.parse_args()


def run_all(p):
    print("**************************************************************")
    print("Running All modules")
    print("**************************************************************")
    run_iris(p)
    run_spam(p)
    run_mushroom_multiway(p)
    run_mushroom_binary(p)
    run_housing(p)


if __name__ == '__main__':

    p = Path(__file__).parents[1]
    args = gather_arguments()
    models_to_run = [key for key, value in args.__dict__.items() if args.__dict__[key]]
    if len(models_to_run) == 0:
        print("Choose correct option or use -h for help")
        exit(0)
    model_map = {'iris': run_iris, 'spambase': run_spam, 'mush_multi': run_mushroom_multiway,
                 'mush_binary': run_mushroom_binary, 'housing': run_housing, 'all': run_all}
    model_map[models_to_run[0]](p)
