Assignment 1

- Install all the required libraries
	- Install pipenv using 'pip3 install pipenv'
	- Start the virtual env (in the same directory the Pipfile and Pipfile.lock are present) using 'pipenv shell'
	- Make sure you have the required libraries installed and installing one if the errors occur (if your python version is not 3.7 maybe)
	- The program was developed on a system with all libraries is the 'system_requirements.txt' file.
	
- To run the program, cd into the directory where this Readme is placed. (ie, you should see a src/ folder)
- Run the code with the following command 
    python src/run.py -{flagname}
		where flagname has the following flags
		--iris, -i          Add this option for Q. 1. 1. a. Iris Dataset
		--spambase, -s      Add this option for Q. 1. 1. b. Spambase Dataset
		--mush_multi, -mm   Add this option for Q. 2. 1. a. Multiway Mushroom
							Dataset
		--mush_binary, -mb  Add this option for Q. 2. 1. b. Binary Mushroom Dataset
		--housing, -hr      Add this option for Q. 6. a. Housing Dataset
		--all, -a           Add this option to run models for all the above datasets
		
- To know more, use the -h flag, ie, 
	python src/run.py -h
	
	usage: run.py [-h] [--iris] [--spambase] [--mush_multi] [--mush_binary]
              [--housing] [--all]

	Assignment 1 for CS6140

	optional arguments:
	-h, --help          show this help message and exit
	--iris, -i          Add this option for Q. 1. 1. a. Iris Dataset
	--spambase, -s      Add this option for Q. 1. 1. b. Spambase Dataset
	--mush_multi, -mm   Add this option for Q. 2. 1. a. Multiway Mushroom
                      Dataset
	--mush_binary, -mb  Add this option for Q. 2. 1. b. Binary Mushroom Dataset
	--housing, -hr      Add this option for Q. 6. a. Housing Dataset
	--all, -a           Add this option to run models for all the above datasets
	
- Make sure to run the code from the above specified directory. Failing in doing so, will give a indexError (for the pathlib library)