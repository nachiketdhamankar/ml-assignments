from util import get_data, get_sse, get_normalized_mutual_information, plot_graph, multivariate_gaussian
import pandas as pd
import numpy as np
from math import isclose
from question3 import run_k_means_model


def get_initial_mean_cov(x, num_components):
    sse, classification, mu = run_k_means_model(x=x, num_clusters=num_components, max_iterations=1000, tolerance=0.001)

    sigma = np.zeros([num_components, x.shape[1], x.shape[1]])
    pi = np.zeros(num_components)

    for k in range(num_components):
        sigma[k] = np.cov(x[classification == k].T) if (classification == k).sum() > 1 else sigma[k]
        pi[k] = (classification == k).sum() / x.shape[0]
    return mu, sigma, pi


def _step_e(x, mu, sigma, pi, num_components):
    gamma = np.zeros([x.shape[0], num_components])
    mu = np.nan_to_num(x=mu, nan=0.0)
    sigma = np.nan_to_num(x=sigma, nan=0.0)
    limit = 0

    p = np.zeros(num_components)
    for row_index in range(x.shape[0]):

        for component in range(num_components):
            p[component] = pi[component] * multivariate_gaussian(x[row_index], mu[component], sigma[component])

        for component in range(num_components):
            gamma[row_index, component] = p[component] / p.sum()
        limit += np.log(p.sum())
        p = np.zeros(num_components)
    return gamma, limit


def _step_m(x, num_components, gamma, sigma):
    n_k = gamma.sum(axis=0)
    n_k = np.nan_to_num(x=n_k, nan=0.0)

    mu = gamma.T.dot(x) / n_k[:, None]
    mu = np.nan_to_num(x=mu, nan=0.0)

    for j in range(num_components):
        s = 0
        for i in range(x.shape[0]):
            diff = x[i] - mu[j]
            s += gamma[i, j] * np.outer(diff, diff)
        sigma[j] = s / n_k[j]
        sigma = np.nan_to_num(x=sigma, nan=0.0)
    pi = n_k / x.shape[0]
    return mu, sigma, pi, gamma


def predict(x, mu, sigma, pi, num_components):
    gamma = np.zeros([x.shape[0], num_components])
    for row_index in range(x.shape[0]):
        p = np.zeros(num_components)
        for component in range(num_components):
            p[component] = pi[component] * multivariate_gaussian(x[row_index], mu[component], sigma[component])

        for component in range(num_components):
            gamma[row_index, component] = p[component] / p.sum()

    prediction = np.argmax(gamma, axis=1)
    return prediction


def run_gmm_model(x, max_iterations, tolerance, num_components):
    means, cov, weights = get_initial_mean_cov(x=x, num_components=num_components)
    prev_lower_bound = float('-inf')
    for iteration in range(max_iterations):
        gamma, lower_bound = _step_e(x=x, mu=means, sigma=cov, pi=weights,
                                     num_components=num_components)
        means, cov, weights, gamma = _step_m(x=x, sigma=cov, num_components=num_components, gamma=gamma)
        if isclose(prev_lower_bound, lower_bound, abs_tol=tolerance):
            break
        prev_lower_bound = lower_bound

    classification = predict(x=x, mu=means, sigma=cov, pi=weights, num_components=num_components)
    sse = get_sse(x, classification, means)
    return sse, classification, means


def run_gmm(data, max_iter, tolerence, max_components, dataset_name, save_fig=False, num_class_cluster_equal=False):
    x = data.iloc[:, :-1].values
    y = data.iloc[:, -1].values
    num_of_classes = max_components if num_class_cluster_equal else len(data.iloc[:, -1].unique())

    list_sse = []
    list_nmi = []
    for components in range(max_components):
        sse, classification, mean = run_gmm_model(x=x, num_components=components + 1, max_iterations=max_iter,
                                                  tolerance=tolerence)
        nmi = get_normalized_mutual_information(y, num_of_classes, classification, components + 1)
        list_sse.append(sse)
        list_nmi.append(nmi)

        print('Number of Components: %s\n\tSSE: %s\n\tNMI: %s\n' % (components + 1, sse, nmi))

    plot_graph(list_sse, max_components + 1, label="SSE v/s K", dataset_name=dataset_name, save_fig=save_fig)
    plot_graph(list_nmi, max_components + 1, label="NMI v/s K", dataset_name=dataset_name, save_fig=save_fig)


def ecoli():
    print('ECOLI')
    data = get_data('ecoliData')
    # Change to false when needed
    class_cluster_equal = False
    suffix = "_equal_class_cluster" if class_cluster_equal else "_unequal_class_cluster"
    dataset_name = "question4/Ecoli" + suffix
    run_gmm(data=data, max_components=10, max_iter=1000, tolerence=0.0001, dataset_name=dataset_name,
            save_fig=True, num_class_cluster_equal=class_cluster_equal)


def glass():
    print('GLASS')
    data = get_data('glassData')
    # Change to false when needed
    class_cluster_equal = False
    suffix = "_equal_class_cluster" if class_cluster_equal else "_unequal_class_cluster"
    dataset_name = "question4/Glass" + suffix
    run_gmm(data=data, max_components=10, max_iter=1000, tolerence=0.0001, dataset_name=dataset_name,
            save_fig=True, num_class_cluster_equal=class_cluster_equal)


def vowels():
    print('VOWELS')
    data = get_data('vowelsData')
    # Change to false when needed
    class_cluster_equal = False
    suffix = "_equal_class_cluster" if class_cluster_equal else "_unequal_class_cluster"
    dataset_name = "question4/Vowels" + suffix
    run_gmm(data=data, max_components=10, max_iter=1000, tolerence=0.0001, dataset_name=dataset_name,
            save_fig=True, num_class_cluster_equal=class_cluster_equal)


def dermatology():
    print('DERMATOLOGY')
    data = get_data('dermatologyData')
    # Change to false when needed
    class_cluster_equal = False
    suffix = "_equal_class_cluster" if class_cluster_equal else "_unequal_class_cluster"
    dataset_name = "question4/Dermatology" + suffix
    run_gmm(data=data, max_components=10, max_iter=1000, tolerence=0.0001, dataset_name=dataset_name,
            save_fig=True, num_class_cluster_equal=class_cluster_equal)


def soybeans():
    print('SOYBEANS')
    data = get_data('soybeanData')
    # Change to false when needed
    class_cluster_equal = False
    suffix = "_equal_class_cluster" if class_cluster_equal else "_unequal_class_cluster"
    dataset_name = "question4/Soybeans" + suffix
    run_gmm(data=data, max_components=10, max_iter=1000, tolerence=0.0001, dataset_name=dataset_name,
            save_fig=True, num_class_cluster_equal=class_cluster_equal)


def yeast():
    print('YEAST')
    data = get_data('yeastData')
    # Change to false when needed
    class_cluster_equal = False
    suffix = "_equal_class_cluster" if class_cluster_equal else "_unequal_class_cluster"
    dataset_name = "question4/Yeast" + suffix
    run_gmm(data=data, max_components=10, max_iter=1000, tolerence=0.0001, dataset_name=dataset_name,
            save_fig=True, num_class_cluster_equal=class_cluster_equal)


if __name__ == '__main__':
    # Uncomment to display all columns
    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    # ecoli()
    # glass()
    # vowels()
    # dermatology()
    # soybeans()
    yeast()
