import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import multivariate_normal


def get_data(dataset_name):
    file_name = "../dataset/" + dataset_name + ".csv"
    data = pd.read_csv(file_name, header=None)
    return data


def get_sse(x, labels, centroids):
    sum_squared_error = 0
    for row_index in range(x.shape[0]):
        difference = x[row_index] - centroids[labels[row_index]]
        squared_error = difference.dot(difference)
        sum_squared_error += squared_error
    return sum_squared_error


def get_mutual_information(classes, num_classes, clusters, num_clusters, class_entropy):
    conditional_prob_class_per_cluster = 0
    for cluster in range(num_clusters):
        cluster_prob = classes[clusters == cluster]
        cluster_entropy = 0 if cluster_prob.shape[0] == 0 else get_entropy(cluster_prob, num_classes)

        class_prob = np.sum(clusters == cluster) / classes.shape[0]
        conditional_prob_class_per_cluster += class_prob * cluster_entropy

    return class_entropy - conditional_prob_class_per_cluster


def get_normalized_mutual_information(classes, num_classes, clusters, num_clusters):
    class_entropy = 0 if classes.shape[0] == 0 else get_entropy(labels=classes,
                                                                possible_labels=num_classes)  # Class entropy
    I_y_c = get_mutual_information(classes=classes, num_classes=num_classes, clusters=clusters,
                                   num_clusters=num_clusters,
                                   class_entropy=class_entropy)
    cluster_entropy = 0 if clusters.shape[0] == 0 else get_entropy(labels=clusters,
                                                                   possible_labels=num_clusters)  # Cluster entropy
    return (2 * I_y_c) / (class_entropy + cluster_entropy)


def plot_graph(values, num_clusters, label, dataset_name=None, save_fig=False):
    fig, ax = plt.subplots()
    ax.plot(range(1, num_clusters), values, '-k*')
    ax.set_xticks(range(num_clusters))
    ax.set(xlabel='Cluster - K', ylabel=label.split("v/s")[0], title=label)
    ax.grid()
    if save_fig:
        plt.savefig('../graphs/' + dataset_name + '_' + label.split("v/s")[0] + '.png')
    plt.show()


def multivariate_gaussian(x, mu, sigma):
    return multivariate_normal.pdf(x, mean=mu, cov=sigma, allow_singular=True)


def get_entropy(labels, possible_labels):
    entropy = 0
    for label in range(possible_labels):
        py = np.sum(labels == label) / labels.shape[0]
        entropy -= py * np.log2(py) if py != 0 else 0
    return entropy
