from util import get_data, get_sse, get_normalized_mutual_information, plot_graph
import pandas as pd
import numpy as np
from math import isclose

np.seterr(divide='ignore', invalid='ignore')


def classify(x, n_clusters, centroids):
    m = x.shape[0]
    z_matrix = np.zeros(m, dtype=int)

    for row_index in range(m):
        squared_errors = np.zeros(n_clusters)
        for cluster in range(n_clusters):
            difference = x[row_index] - centroids[cluster]
            squared_errors[cluster] = difference.dot(difference)
        z_matrix[row_index] = np.argmin(squared_errors)
    return z_matrix


def get_updated_centroid(x, n_clusters, classification):
    updated_centroids = np.zeros((n_clusters, x.shape[1]))
    for cluster in range(n_clusters):
        val = np.mean(x[classification == cluster], axis=0)
        val = np.nan_to_num(x=val, nan=0.0)
        updated_centroids[cluster] = val
    return updated_centroids


def run_k_means_model(x, num_clusters, max_iterations, tolerance):
    centroids = np.random.rand(num_clusters, x.shape[1])
    classification = np.zeros(x.shape[0], dtype=int)

    prev_sse = float('-inf')
    for i in range(max_iterations):
        classification = classify(x, num_clusters, centroids)
        centroids = get_updated_centroid(x, num_clusters, classification)
        sse = get_sse(x, classification, centroids)
        if isclose(sse, prev_sse, abs_tol=tolerance):
            break
        prev_sse = sse

    return sse, classification, centroids


def run_k_means(data, max_iter, tolerence, num_clusters, dataset_name, save_fig=False):
    x = data.iloc[:, :-1].values
    y = data.iloc[:, -1].values
    num_of_classes = len(data.iloc[:, -1].unique())

    list_sse = []
    list_nmi = []
    for cluster in range(num_clusters):
        sum_square_error, classification, _centroids = run_k_means_model(x, cluster + 1, max_iter, tolerence)
        nmi = get_normalized_mutual_information(y, num_of_classes, classification, cluster + 1)
        list_sse.append(sum_square_error)
        list_nmi.append(nmi)

        print('Number of Clusters: %s\n\tSSE: %s\n\tNMI: %s\n' % (cluster + 1, sum_square_error, nmi))

    plot_graph(list_sse, num_clusters + 1, label="SSE v/s K", dataset_name=dataset_name, save_fig=save_fig)
    plot_graph(list_nmi, num_clusters + 1, label="NMI v/s K", dataset_name=dataset_name, save_fig=save_fig)


def ecoli():
    print('ECOLI')
    data = get_data('ecoliData')
    run_k_means(data=data, num_clusters=25, max_iter=1000, tolerence=0.0001, dataset_name='question3/Ecoli',
                save_fig=True)


def glass():
    print('GLASS')
    data = get_data('glassData')
    run_k_means(data=data, num_clusters=25, max_iter=1000, tolerence=0.0001, dataset_name='question3/Glass',
                save_fig=True)


def vowels():
    print('VOWELS')
    data = get_data('vowelsData')
    run_k_means(data=data, num_clusters=25, max_iter=1000, tolerence=0.0001, dataset_name='question3/Vowels',
                save_fig=True)


def dermatology():
    print('DERMATOLOGY')
    data = get_data('dermatologyData')
    run_k_means(data=data, num_clusters=25, max_iter=1000, tolerence=0.0001, dataset_name='question3/dermatology',
                save_fig=True)


def soyBean():
    print('SOYBEAN')
    data = get_data('soybeanData')
    run_k_means(data=data, num_clusters=25, max_iter=1000, tolerence=0.0001, dataset_name='question3/soybean',
                save_fig=True)


def yeast():
    print('YEAST')
    data = get_data('yeastData')
    run_k_means(data=data, num_clusters=25, max_iter=1000, tolerence=0.0001, dataset_name='question3/yeast',
                save_fig=True)


if __name__ == '__main__':
    # Uncomment to display all columns
    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    # ecoli()
    # glass()
    # vowels()
    dermatology()
    # soyBean()
    # yeast()
