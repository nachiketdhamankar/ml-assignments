
- All the source code is present in the \src\ folder with appropriate filename (according to the question number)
- All the output of the source code is in the \output\ folder with appropriate directory (according to the question number)
- All the graphs are in the \graphs\ folder with appropriate directory (according to the question number)
- All the tables are in the \tables\ folder with appropriate directory (according to the question number)
- Written answers for question 3 and 5 are in the \answers\ folder

Question 3.
- 3.1.1., 3.1.2. - Programming Task
- 3.1.3. - in \answers\question3_1_3.txt and \tables\Question 3.docx
- 3.2.1. - in \graphs\question3\ 
- 3.2.2. and 3.2.3. - in \tables\Question 3.docx

Question 4.
- 4.1.1., 4.1.2., 4.1.3. - Programming task
- 4.1.4 - in \answers\question4_1_4.txt
- 4.2.1. and 4.2.2. - Programming task
- 4.2.3. 4.2.4 and 4.2.5. - In \tables\Question 4.docx

Question 5.
- 5.1 and 5.2 - in \answers\question5.txt	
	
Code
- All code is in the src\ folder.
- Install pipenv
- Install the requirements using 
	``` pipenv install -r requirements.txt ```
- cd into src\ using
	``` cd src ```
- Make the necessary changes in the file (Uncomment the appropriate lines. More instructions in each of the file) and run using
	``` python {filename}.py ```

* Note
 - Make sure you do not change the file structure (or remove files from the submission). My program does not create folders if they're not present and will throw an exception.